import React, { useState } from 'react';
import { Wifi, Signal, BatteryCharging, Battery, ChevronDown, ChevronUp, Bell, SquareCheck } from 'lucide-react';
import { GatewayState } from '../types/gateway';

interface AndroidStatusTrayProps {
  gatewayState: GatewayState;
  port: number;
  sentToday: number;
  batteryPct: number;
  onStopGateway: () => void;
  lang: 'en' | 'am';
}

export const AndroidStatusTray: React.FC<AndroidStatusTrayProps> = ({
  gatewayState,
  port,
  sentToday,
  batteryPct,
  onStopGateway,
  lang,
}) => {
  const [trayExpanded, setTrayExpanded] = useState(false);
  const now = new Date();
  const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });

  return (
    <div className="bg-slate-950 text-slate-200 select-none text-xs">
      {/* Top Status Bar */}
      <div 
        onClick={() => setTrayExpanded(!trayExpanded)}
        className="flex items-center justify-between px-4 py-1.5 cursor-pointer hover:bg-slate-900 transition-colors"
      >
        <div className="flex items-center gap-1.5 font-medium tracking-tight">
          <span>{timeString}</span>
          {gatewayState === 'RUNNING' && (
            <span className="flex items-center gap-1 text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800/80 px-1.5 py-0.2 rounded font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              HTTP :{port}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2 text-slate-300">
          <Wifi className="w-3.5 h-3.5" />
          <Signal className="w-3.5 h-3.5" />
          <div className="flex items-center gap-0.5">
            <span className="text-[11px] font-mono">{batteryPct}%</span>
            <Battery className="w-3.5 h-3.5" />
          </div>
          {trayExpanded ? <ChevronUp className="w-3 h-3 text-slate-400" /> : <ChevronDown className="w-3 h-3 text-slate-400" />}
        </div>
      </div>

      {/* Expandable Notification Shade */}
      {trayExpanded && (
        <div className="bg-slate-900 border-b border-slate-800 p-3 space-y-2 animate-in slide-in-from-top duration-200">
          <div className="flex items-center justify-between text-slate-400 text-[11px]">
            <span className="font-semibold uppercase tracking-wider flex items-center gap-1">
              <Bell className="w-3 h-3 text-blue-400" /> Android System • Foreground Services
            </span>
            <span>Silent notification</span>
          </div>

          {gatewayState === 'RUNNING' ? (
            <div className="bg-slate-800/90 rounded-lg p-3 border border-blue-900/40 shadow-sm">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-1.5 text-blue-400 font-semibold text-xs">
                    <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                    JM SMS Gateway is Active
                  </div>
                  <p className="text-slate-300 text-xs mt-0.5 font-mono">
                    Ready on port {port} • Sent today: {sentToday}
                  </p>
                  <p className="text-slate-500 text-[10px] mt-0.5">
                    Data Sync foreground service running continuously
                  </p>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onStopGateway();
                  }}
                  className="px-2.5 py-1 text-xs bg-red-600/90 hover:bg-red-500 text-white rounded font-medium transition-colors"
                >
                  {lang === 'am' ? 'አቁም' : 'Stop'}
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-slate-800/50 rounded-lg p-2.5 text-center text-slate-400 text-xs">
              No active foreground services running.
            </div>
          )}
        </div>
      )}
    </div>
  );
};
