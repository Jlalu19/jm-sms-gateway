import React, { useState } from 'react';
import { X, Save, Server, Shield, Power, Globe, Palette } from 'lucide-react';
import { GatewaySettings } from '../types/gateway';
import { translations } from '../locales/translations';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: GatewaySettings;
  onSave: (updated: GatewaySettings) => void;
  lang: 'en' | 'am';
  onLanguageChange: (lang: 'en' | 'am') => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSave,
  lang,
  onLanguageChange,
}) => {
  const [port, setPort] = useState(settings.port);
  const [maxRetries, setMaxRetries] = useState(settings.maxRetries);
  const [retryDelay, setRetryDelay] = useState(settings.retryDelaySeconds);
  const [autoStart, setAutoStart] = useState(settings.autoStartOnBoot);
  const [batteryOpt, setBatteryOpt] = useState(settings.ignoreBatteryOptimization);
  const t = translations[lang];

  if (!isOpen) return null;

  const handleSave = () => {
    onSave({
      ...settings,
      port,
      maxRetries,
      retryDelaySeconds: retryDelay,
      autoStartOnBoot: autoStart,
      ignoreBatteryOptimization: batteryOpt,
      language: lang,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="bg-slate-900 border border-slate-800 text-slate-100 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-900">
          <div className="flex items-center gap-2">
            <Server className="w-5 h-5 text-blue-500" />
            <h3 className="font-semibold text-base">{t.settings}</h3>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-5 text-sm">
          {/* Language Selection */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-blue-400" /> Language / ቋንቋ
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => onLanguageChange('en')}
                className={`py-2 px-3 rounded-lg border text-xs font-medium transition ${
                  lang === 'en'
                    ? 'bg-blue-600/20 border-blue-500 text-blue-300'
                    : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:bg-slate-800'
                }`}
              >
                English (US)
              </button>
              <button
                type="button"
                onClick={() => onLanguageChange('am')}
                className={`py-2 px-3 rounded-lg border text-xs font-medium transition ${
                  lang === 'am'
                    ? 'bg-blue-600/20 border-blue-500 text-blue-300'
                    : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:bg-slate-800'
                }`}
              >
                አማርኛ (Amharic)
              </button>
            </div>
          </div>

          {/* HTTP Port */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Server className="w-3.5 h-3.5 text-blue-400" /> {t.port}
            </label>
            <input
              type="number"
              min={1024}
              max={65535}
              value={port}
              onChange={(e) => setPort(parseInt(e.target.value) || 8080)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 font-mono focus:outline-hidden focus:border-blue-500"
            />
            <p className="text-[11px] text-amber-400/90 leading-tight">
              {t.portNotice}
            </p>
          </div>

          {/* Queue & Retries */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-400">Max Retries</label>
              <input
                type="number"
                min={1}
                max={10}
                value={maxRetries}
                onChange={(e) => setMaxRetries(parseInt(e.target.value) || 3)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 font-mono"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-400">Retry Delay (sec)</label>
              <input
                type="number"
                min={1}
                max={60}
                value={retryDelay}
                onChange={(e) => setRetryDelay(parseInt(e.target.value) || 5)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 font-mono"
              />
            </div>
          </div>

          {/* System Toggles */}
          <div className="space-y-3 pt-2 border-t border-slate-800">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium text-slate-200 text-xs flex items-center gap-1.5">
                  <Power className="w-3.5 h-3.5 text-emerald-400" /> {t.autoStartTitle}
                </div>
                <div className="text-[11px] text-slate-400">
                  RECEIVE_BOOT_COMPLETED broadcast trigger
                </div>
              </div>
              <input
                type="checkbox"
                checked={autoStart}
                onChange={(e) => setAutoStart(e.target.checked)}
                className="w-4 h-4 accent-blue-600 rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium text-slate-200 text-xs flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-blue-400" /> {t.batteryOptTitle}
                </div>
                <div className="text-[11px] text-slate-400">
                  REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
                </div>
              </div>
              <input
                type="checkbox"
                checked={batteryOpt}
                onChange={(e) => setBatteryOpt(e.target.checked)}
                className="w-4 h-4 accent-blue-600 rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/80 flex items-center justify-end gap-2">
          <button
            onClick={onClose}
            className="px-3 py-1.5 text-xs text-slate-400 hover:text-white rounded-lg transition"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="flex items-center gap-1.5 px-4 py-1.5 text-xs bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-medium transition shadow-md shadow-blue-900/30"
          >
            <Save className="w-3.5 h-3.5" />
            {t.saveSettings}
          </button>
        </div>
      </div>
    </div>
  );
};
