import React, { useState } from 'react';
import { Search, Download, Trash2, ArrowLeft, Filter, AlertTriangle, Info, CheckCircle2, ShieldAlert } from 'lucide-react';
import { SmsLog } from '../types/gateway';
import { translations } from '../locales/translations';

interface LogsViewProps {
  logs: SmsLog[];
  onBack: () => void;
  onClearLogs: () => void;
  lang: 'en' | 'am';
}

export const LogsView: React.FC<LogsViewProps> = ({
  logs,
  onBack,
  onClearLogs,
  lang,
}) => {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const t = translations[lang];

  const filtered = logs.filter((log) => {
    const matchesSearch =
      search.trim() === '' ||
      log.message.toLowerCase().includes(search.toLowerCase()) ||
      (log.recipient && log.recipient.includes(search)) ||
      log.category.toLowerCase().includes(search.toLowerCase());

    const matchesCategory =
      selectedCategory === 'ALL' || log.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  const handleExportCsv = () => {
    const headers = ['ID', 'Timestamp', 'Category', 'Level', 'Recipient', 'Status', 'Message'];
    const rows = logs.map((l) => [
      l.id,
      new Date(l.timestamp).toISOString(),
      l.category,
      l.level,
      l.recipient || '',
      l.status || '',
      `"${l.message.replace(/"/g, '""')}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `jm_sms_gateway_logs_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getLevelBadge = (level: string, status?: string) => {
    if (status === 'SENT' || status === 'DELIVERED') {
      return (
        <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-950/70 border border-emerald-800/80 px-2 py-0.5 rounded">
          <CheckCircle2 className="w-3 h-3" /> {status}
        </span>
      );
    }
    if (level === 'ERROR' || status === 'FAILED') {
      return (
        <span className="flex items-center gap-1 text-[11px] font-semibold text-red-400 bg-red-950/70 border border-red-800/80 px-2 py-0.5 rounded">
          <AlertTriangle className="w-3 h-3" /> {status || 'ERROR'}
        </span>
      );
    }
    if (level === 'WARNING' || status === 'RETRYING') {
      return (
        <span className="flex items-center gap-1 text-[11px] font-semibold text-amber-400 bg-amber-950/70 border border-amber-800/80 px-2 py-0.5 rounded">
          <AlertTriangle className="w-3 h-3" /> {status || 'WARNING'}
        </span>
      );
    }
    if (level === 'SECURITY') {
      return (
        <span className="flex items-center gap-1 text-[11px] font-semibold text-purple-400 bg-purple-950/70 border border-purple-800/80 px-2 py-0.5 rounded">
          <ShieldAlert className="w-3 h-3" /> SECURITY
        </span>
      );
    }
    return (
      <span className="flex items-center gap-1 text-[11px] font-semibold text-blue-400 bg-blue-950/70 border border-blue-800/80 px-2 py-0.5 rounded">
        <Info className="w-3 h-3" /> INFO
      </span>
    );
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 text-slate-100">
      {/* Action Bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-blue-700 text-white shadow-md">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-1 hover:bg-blue-600 rounded-lg transition">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="font-semibold text-base">{t.logs}</h2>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={handleExportCsv}
            title={t.exportCsv}
            className="p-1.5 hover:bg-blue-600 rounded-lg transition text-blue-100 hover:text-white"
          >
            <Download className="w-4 h-4" />
          </button>
          <button
            onClick={onClearLogs}
            title={t.clearLogs}
            className="p-1.5 hover:bg-red-600 rounded-lg transition text-blue-100 hover:text-white"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="p-3 bg-slate-900 border-b border-slate-800 space-y-2">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-hidden focus:border-blue-500"
          />
        </div>

        {/* Category Pills */}
        <div className="flex gap-1.5 overflow-x-auto text-[11px] pb-1">
          {['ALL', 'SMS', 'SERVER', 'PAIRING', 'SYSTEM'].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded-full whitespace-nowrap transition font-medium ${
                selectedCategory === cat
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Logs List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {filtered.length === 0 ? (
          <div className="text-center py-12 text-slate-500 text-xs">
            No matching log entries found.
          </div>
        ) : (
          filtered.map((log) => (
            <div
              key={log.id}
              className="bg-slate-950/70 border border-slate-800 rounded-xl p-3 space-y-1.5 text-xs shadow-xs hover:border-slate-700 transition"
            >
              <div className="flex items-center justify-between">
                <span className="font-mono font-semibold text-slate-200">
                  {log.recipient || `[${log.category}]`}
                </span>
                {getLevelBadge(log.level, log.status)}
              </div>
              <p className="text-slate-300 text-xs leading-relaxed">{log.message}</p>
              <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-900 font-mono">
                <span>{log.category}</span>
                <span>{new Date(log.timestamp).toLocaleTimeString()}</span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
