import React, { useState } from 'react';
import { X, QrCode, Camera, CheckCircle2, AlertCircle, Laptop, RefreshCw } from 'lucide-react';
import { PairedDesktop } from '../types/gateway';
import { translations } from '../locales/translations';

interface PairingModalProps {
  isOpen: boolean;
  onClose: () => void;
  pairedDesktop: PairedDesktop | null;
  onPairSuccess: (desktop: PairedDesktop) => void;
  onUnpair: () => void;
  lang: 'en' | 'am';
}

export const PairingModal: React.FC<PairingModalProps> = ({
  isOpen,
  onClose,
  pairedDesktop,
  onPairSuccess,
  onUnpair,
  lang,
}) => {
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [rawPayload, setRawPayload] = useState('');
  const t = translations[lang];

  if (!isOpen) return null;

  const simulateQrScan = () => {
    setScanning(true);
    setError(null);

    setTimeout(() => {
      try {
        const dummyPayload = {
          desktopId: 'DESKTOP-JM-PRO-984',
          computerName: 'Finance-Workstation-01',
          licenseId: 'LIC-JM-2026-ETH',
          pairingSecret: 'sec_' + Math.random().toString(36).substring(2, 15),
          desktopHost: '192.168.1.100',
          desktopPort: 9090,
          issuedAt: Date.now(),
        };

        const newPaired: PairedDesktop = {
          desktopId: dummyPayload.desktopId,
          computerName: dummyPayload.computerName,
          pairingSecret: dummyPayload.pairingSecret,
          licenseId: dummyPayload.licenseId,
          desktopHost: dummyPayload.desktopHost,
          desktopPort: dummyPayload.desktopPort,
          isActive: true,
          pairedAt: Date.now(),
          lastSeenAt: Date.now(),
        };

        onPairSuccess(newPaired);
        setScanning(false);
        setSuccess(true);
        setTimeout(() => {
          setSuccess(false);
          onClose();
        }, 1200);
      } catch (err: any) {
        setScanning(false);
        setError(err.message || 'Pairing failed');
      }
    }, 1500);
  };

  const handleManualPair = () => {
    try {
      const parsed = JSON.parse(rawPayload);
      if (!parsed.desktopId || !parsed.pairingSecret) {
        throw new Error('Missing desktopId or pairingSecret in QR payload');
      }
      const newPaired: PairedDesktop = {
        desktopId: parsed.desktopId,
        computerName: parsed.computerName || 'Desktop Client',
        pairingSecret: parsed.pairingSecret,
        licenseId: parsed.licenseId,
        desktopHost: parsed.desktopHost || '192.168.1.100',
        desktopPort: parsed.desktopPort || 9090,
        isActive: true,
        pairedAt: Date.now(),
        lastSeenAt: Date.now(),
      };
      onPairSuccess(newPaired);
      onClose();
    } catch (e: any) {
      setError('Invalid QR JSON payload: ' + e.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
      <div className="bg-slate-900 border border-slate-800 text-slate-100 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-900">
          <div className="flex items-center gap-2">
            <QrCode className="w-5 h-5 text-blue-500" />
            <h3 className="font-semibold text-base">{t.pairing}</h3>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {pairedDesktop ? (
            <div className="bg-emerald-950/40 border border-emerald-800/60 rounded-xl p-4 space-y-3">
              <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
                <CheckCircle2 className="w-4 h-4" />
                Active Paired Desktop
              </div>
              <div className="text-xs space-y-1 font-mono text-slate-300">
                <div><span className="text-slate-500">Host:</span> {pairedDesktop.computerName}</div>
                <div><span className="text-slate-500">IP:</span> {pairedDesktop.desktopHost}:{pairedDesktop.desktopPort}</div>
                <div><span className="text-slate-500">Desktop ID:</span> {pairedDesktop.desktopId}</div>
                <div className="text-[10px] text-slate-500 truncate"><span className="text-slate-500">Secret:</span> {pairedDesktop.pairingSecret}</div>
              </div>
              <div className="pt-2 flex justify-end">
                <button
                  onClick={onUnpair}
                  className="px-3 py-1.5 text-xs bg-red-600/80 hover:bg-red-500 text-white rounded-lg font-medium transition"
                >
                  Unpair Desktop
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* Simulated Camera Viewfinder */}
              <div className="relative aspect-4/3 bg-slate-950 border border-slate-800 rounded-xl overflow-hidden flex flex-col items-center justify-center p-4">
                {scanning ? (
                  <div className="flex flex-col items-center gap-2 text-blue-400">
                    <RefreshCw className="w-8 h-8 animate-spin" />
                    <span className="text-xs font-mono">Analyzing CameraX QR Stream…</span>
                  </div>
                ) : success ? (
                  <div className="flex flex-col items-center gap-2 text-emerald-400">
                    <CheckCircle2 className="w-10 h-10 animate-bounce" />
                    <span className="text-xs font-semibold">{t.pairingSuccess}</span>
                  </div>
                ) : (
                  <>
                    <div className="w-44 h-44 border-2 border-dashed border-blue-500/70 rounded-xl flex items-center justify-center relative">
                      <div className="w-3 h-3 border-t-2 border-l-2 border-blue-400 absolute top-1 left-1"></div>
                      <div className="w-3 h-3 border-t-2 border-r-2 border-blue-400 absolute top-1 right-1"></div>
                      <div className="w-3 h-3 border-b-2 border-l-2 border-blue-400 absolute bottom-1 left-1"></div>
                      <div className="w-3 h-3 border-b-2 border-r-2 border-blue-400 absolute bottom-1 right-1"></div>
                      <Camera className="w-8 h-8 text-slate-600" />
                    </div>
                    <p className="text-[11px] text-slate-400 text-center mt-3 max-w-xs">
                      {t.scanPrompt}
                    </p>
                  </>
                )}
              </div>

              {error && (
                <div className="flex items-center gap-2 p-2.5 rounded-lg bg-red-950/60 border border-red-800/80 text-red-300 text-xs">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <button
                onClick={simulateQrScan}
                disabled={scanning}
                className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 shadow-lg shadow-blue-900/30 transition"
              >
                <QrCode className="w-4 h-4" />
                Scan QR from JM Connector Desktop
              </button>

              {/* Or manual JSON paste for testing */}
              <div className="pt-2 border-t border-slate-800 space-y-2">
                <div className="text-[11px] font-medium text-slate-400">
                  Or Paste Raw Pairing QR Payload (JSON):
                </div>
                <textarea
                  value={rawPayload}
                  onChange={(e) => setRawPayload(e.target.value)}
                  placeholder='{"desktopId":"D1","computerName":"PC-1","pairingSecret":"sec_123","desktopHost":"192.168.1.10","desktopPort":9090}'
                  className="w-full h-16 bg-slate-950 border border-slate-700 rounded-lg p-2 text-[11px] font-mono text-slate-300 resize-none focus:outline-hidden focus:border-blue-500"
                />
                <button
                  onClick={handleManualPair}
                  className="w-full py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg transition"
                >
                  Verify and Pair Payload
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
