import React from 'react';

interface PhoneFrameProps {
  children: React.ReactNode;
}

export const PhoneFrame: React.FC<PhoneFrameProps> = ({ children }) => {
  return (
    <div className="relative mx-auto w-full max-w-[380px] h-[780px] bg-slate-900 rounded-[48px] p-3 shadow-2xl ring-1 ring-slate-800 border-4 border-slate-800 flex flex-col overflow-hidden">
      {/* Speaker / Camera Notch */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2">
        <div className="w-12 h-1 bg-slate-800 rounded-full"></div>
        <div className="w-3.5 h-3.5 bg-black rounded-full ring-2 ring-slate-800 flex items-center justify-center">
          <div className="w-1 h-1 bg-blue-900/60 rounded-full"></div>
        </div>
      </div>

      {/* Screen Area */}
      <div className="flex-1 w-full bg-slate-950 rounded-[38px] overflow-hidden flex flex-col relative pt-4 pb-2">
        {children}

        {/* Android Gesture Bar */}
        <div className="w-full flex items-center justify-center py-1 bg-slate-950 select-none">
          <div className="w-28 h-1 bg-slate-700/80 rounded-full"></div>
        </div>
      </div>
    </div>
  );
};
