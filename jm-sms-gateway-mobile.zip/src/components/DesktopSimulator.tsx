import React, { useState } from 'react';
import { 
  Laptop, Send, RefreshCw, Activity, ShieldCheck, 
  CheckCircle2, AlertTriangle, Key, Terminal, QrCode, Copy 
} from 'lucide-react';
import { GatewayState, PairedDesktop } from '../types/gateway';

interface DesktopSimulatorProps {
  gatewayState: GatewayState;
  port: number;
  ipAddress: string;
  pairedDesktop: PairedDesktop | null;
  onSendFromDesktop: (
    recipient: string,
    message: string,
    token: string,
    useNonce: boolean,
    nonce: string,
    timestamp: number
  ) => { statusCode: number; responseBody: any };
  onHeartbeat: (token: string) => { statusCode: number; responseBody: any };
  onGetStatus: () => { statusCode: number; responseBody: any };
}

export const DesktopSimulator: React.FC<DesktopSimulatorProps> = ({
  gatewayState,
  port,
  ipAddress,
  pairedDesktop,
  onSendFromDesktop,
  onHeartbeat,
  onGetStatus,
}) => {
  const [recipient, setRecipient] = useState('+251922334455');
  const [message, setMessage] = useState('ውድ ደንበኛችን፣ የትዕዛዝ ቁጥርዎ #48291 ዝግጁ ነው። JM Technology');
  const [tokenInput, setTokenInput] = useState(pairedDesktop ? pairedDesktop.pairingSecret : 'sec_desktop_demo_key');
  const [useNonce, setUseNonce] = useState(true);
  const [httpResponse, setHttpResponse] = useState<{ statusCode: number; body: any; headers: any } | null>(null);
  const [desktopQrPayload, setDesktopQrPayload] = useState({
    desktopId: 'DESKTOP-JM-CLIENT-01',
    computerName: 'Main-HQ-Server',
    licenseId: 'LIC-JM-ENTERPRISE-2026',
    pairingSecret: 'sec_desktop_demo_key',
    desktopHost: '192.168.1.10',
    desktopPort: 8080,
    issuedAt: Date.now(),
  });
  const [copied, setCopied] = useState(false);

  // Sync token if paired desktop changes
  React.useEffect(() => {
    if (pairedDesktop) {
      setTokenInput(pairedDesktop.pairingSecret);
      setDesktopQrPayload((prev) => ({
        ...prev,
        desktopId: pairedDesktop.desktopId,
        computerName: pairedDesktop.computerName,
        pairingSecret: pairedDesktop.pairingSecret,
      }));
    }
  }, [pairedDesktop]);

  const handleSendSms = () => {
    const nonce = 'nonce_' + Math.random().toString(36).substring(2, 10);
    const ts = Date.now();
    const result = onSendFromDesktop(recipient, message, tokenInput, useNonce, nonce, ts);
    setHttpResponse({
      statusCode: result.statusCode,
      body: result.responseBody,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${tokenInput}`,
        'X-Nonce': useNonce ? nonce : undefined,
        'X-Timestamp': useNonce ? ts : undefined,
      },
    });
  };

  const handleHeartbeat = () => {
    const result = onHeartbeat(tokenInput);
    setHttpResponse({
      statusCode: result.statusCode,
      body: result.responseBody,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${tokenInput}`,
      },
    });
  };

  const handleStatusCheck = () => {
    const result = onGetStatus();
    setHttpResponse({
      statusCode: result.statusCode,
      body: result.responseBody,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  };

  const copyPayload = () => {
    navigator.clipboard.writeText(JSON.stringify(desktopQrPayload, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="h-full flex flex-col bg-slate-950 text-slate-100 p-5 space-y-5 overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-blue-950/80 border border-blue-800/80 rounded-xl text-blue-400">
            <Laptop className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-100">
              JM SMS Connector Desktop — Integration Testbed
            </h2>
            <p className="text-xs text-slate-400">
              Simulates the authorized desktop application communicating with the Android gateway over LAN
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400">Target Gateway:</span>
          <span className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 font-mono text-emerald-400">
            http://{ipAddress}:{port}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Left: Request Control Panel */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
            <h3 className="font-semibold text-xs text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-blue-400" /> Authentication & Security Headers
            </h3>

            <div className="space-y-2 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Bearer Token / Pairing Secret</label>
                <input
                  type="text"
                  value={tokenInput}
                  onChange={(e) => setTokenInput(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 font-mono text-slate-200 focus:outline-hidden focus:border-blue-500"
                />
              </div>

              <div className="flex items-center justify-between pt-1">
                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={useNonce}
                    onChange={(e) => setUseNonce(e.target.checked)}
                    className="accent-blue-600 rounded"
                  />
                  <span>Attach X-Nonce & X-Timestamp (Replay Protection)</span>
                </label>
              </div>
            </div>
          </div>

          {/* Quick API Action Triggers */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
            <h3 className="font-semibold text-xs text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-blue-400" /> Endpoint Actions
            </h3>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={handleStatusCheck}
                className="py-2 px-3 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded-lg font-medium transition text-left flex items-center justify-between"
              >
                <span>GET /api/v1/status</span>
                <span className="text-[10px] text-blue-400 font-mono">Discovery</span>
              </button>

              <button
                onClick={handleHeartbeat}
                className="py-2 px-3 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded-lg font-medium transition text-left flex items-center justify-between"
              >
                <span>POST /api/v1/heartbeat</span>
                <span className="text-[10px] text-emerald-400 font-mono">Ping</span>
              </button>
            </div>
          </div>

          {/* Send SMS Request Form */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
            <h3 className="font-semibold text-xs text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Send className="w-3.5 h-3.5 text-blue-400" /> POST /api/v1/sms/send
            </h3>

            <div className="space-y-2 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Destination Phone Number</label>
                <input
                  type="text"
                  value={recipient}
                  onChange={(e) => setRecipient(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 font-mono text-slate-200"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">SMS Payload (Amharic or English)</label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  rows={2}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-200 resize-none font-mono text-xs"
                />
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  onClick={handleSendSms}
                  className="py-2 px-4 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition shadow-md shadow-blue-900/30"
                >
                  <Send className="w-3.5 h-3.5" />
                  Dispatch SMS to Android Gateway
                </button>
              </div>
            </div>
          </div>

          {/* QR Pairing Generator */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2.5">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-xs text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <QrCode className="w-3.5 h-3.5 text-blue-400" /> Desktop Pairing Payload
              </h3>
              <button
                onClick={copyPayload}
                className="text-[11px] text-blue-400 hover:text-blue-300 flex items-center gap-1"
              >
                <Copy className="w-3 h-3" />
                {copied ? 'Copied!' : 'Copy JSON'}
              </button>
            </div>
            <pre className="p-2.5 bg-slate-950 rounded-lg text-[10px] font-mono text-slate-400 overflow-x-auto border border-slate-800 max-h-28">
              {JSON.stringify(desktopQrPayload, null, 2)}
            </pre>
            <p className="text-[10px] text-slate-500">
              In real deployment, this JSON is encoded as a QR code displayed by JM SMS Connector Desktop for the Android phone to scan.
            </p>
          </div>
        </div>

        {/* Right: HTTP Response Inspector */}
        <div className="flex flex-col bg-slate-900 border border-slate-800 rounded-xl overflow-hidden min-h-[400px]">
          <div className="px-4 py-3 bg-slate-800/80 border-b border-slate-700 flex items-center justify-between">
            <span className="font-semibold text-xs text-slate-200">HTTP Response Inspector</span>
            {httpResponse && (
              <span
                className={`text-xs px-2.5 py-0.5 rounded font-mono font-bold ${
                  httpResponse.statusCode >= 200 && httpResponse.statusCode < 300
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    : httpResponse.statusCode === 409
                    ? 'bg-amber-950 text-amber-300 border border-amber-800'
                    : 'bg-red-950 text-red-300 border border-red-800'
                }`}
              >
                HTTP {httpResponse.statusCode}
              </span>
            )}
          </div>

          <div className="flex-1 p-4 font-mono text-xs overflow-y-auto space-y-4">
            {httpResponse ? (
              <>
                <div className="space-y-1">
                  <div className="text-[11px] text-slate-400 uppercase tracking-wider font-sans">
                    Request Headers:
                  </div>
                  <pre className="p-2 bg-slate-950 rounded-lg text-[11px] text-slate-300 border border-slate-800">
                    {JSON.stringify(httpResponse.headers, null, 2)}
                  </pre>
                </div>

                <div className="space-y-1">
                  <div className="text-[11px] text-slate-400 uppercase tracking-wider font-sans">
                    Response Body (JSON):
                  </div>
                  <pre className="p-3 bg-slate-950 rounded-lg text-emerald-400 border border-slate-800 overflow-x-auto">
                    {JSON.stringify(httpResponse.body, null, 2)}
                  </pre>
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-slate-500 text-center py-16">
                <Terminal className="w-8 h-8 mb-2 opacity-50" />
                <p>Click any endpoint action on the left to execute an HTTP request against the gateway server.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
