import React, { useState } from 'react';
import { 
  Play, Square, QrCode, ScrollText, Settings, Wifi, Smartphone, 
  Send, RefreshCw, AlertCircle, CheckCircle2, Battery, Cpu 
} from 'lucide-react';
import { GatewayState, PairedDesktop, SimCardInfo } from '../types/gateway';
import { translations } from '../locales/translations';

interface DashboardViewProps {
  gatewayState: GatewayState;
  onToggleGateway: () => void;
  sentToday: number;
  failedToday: number;
  pendingCount: number;
  totalSent: number;
  pairedDesktop: PairedDesktop | null;
  port: number;
  ipAddress: string;
  batteryPct: number;
  sims: SimCardInfo[];
  lang: 'en' | 'am';
  onOpenLogs: () => void;
  onOpenSettings: () => void;
  onOpenPairing: () => void;
  onQuickSendSms: (recipient: string, message: string, simSlot: number) => { success: boolean; error?: string };
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  gatewayState,
  onToggleGateway,
  sentToday,
  failedToday,
  pendingCount,
  totalSent,
  pairedDesktop,
  port,
  ipAddress,
  batteryPct,
  sims,
  lang,
  onOpenLogs,
  onOpenSettings,
  onOpenPairing,
  onQuickSendSms,
}) => {
  const [recipient, setRecipient] = useState('+251911223344');
  const [message, setMessage] = useState('ሰላም! ይህ ከJM SMS Gateway የተላከ የሙከራ መልዕክት ነው።');
  const [selectedSlot, setSelectedSlot] = useState(0);
  const [quickSendFeedback, setQuickSendFeedback] = useState<{ msg: string; isError: boolean } | null>(null);

  const t = translations[lang];

  // Unicode & segmentation check
  const isUnicode = Array.from(message).some((char) => char.charCodeAt(0) > 127);
  const maxSingle = isUnicode ? 70 : 160;
  const maxConcat = isUnicode ? 67 : 153;
  const charLength = message.length;
  const segmentCount = charLength === 0 ? 0 : charLength <= maxSingle ? 1 : Math.ceil(charLength / maxConcat);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipient.trim() || !message.trim()) return;
    const res = onQuickSendSms(recipient, message, selectedSlot);
    if (res.success) {
      setQuickSendFeedback({ msg: 'SMS dispatched to queue successfully!', isError: false });
      setTimeout(() => setQuickSendFeedback(null), 3000);
    } else {
      setQuickSendFeedback({ msg: res.error || 'Failed to dispatch SMS', isError: true });
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 text-slate-100">
      {/* Top App Bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-blue-700 text-white shadow-md">
        <div className="flex items-center gap-2">
          <Smartphone className="w-5 h-5 text-blue-200" />
          <h1 className="font-bold text-base tracking-tight">{t.appName}</h1>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={onOpenPairing}
            title={t.pairing}
            className="p-1.5 rounded-lg hover:bg-blue-600 text-blue-100 hover:text-white transition"
          >
            <QrCode className="w-4 h-4" />
          </button>
          <button
            onClick={onOpenLogs}
            title={t.logs}
            className="p-1.5 rounded-lg hover:bg-blue-600 text-blue-100 hover:text-white transition"
          >
            <ScrollText className="w-4 h-4" />
          </button>
          <button
            onClick={onOpenSettings}
            title={t.settings}
            className="p-1.5 rounded-lg hover:bg-blue-600 text-blue-100 hover:text-white transition"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Service Controller Card */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="relative flex h-3.5 w-3.5">
                {gatewayState === 'RUNNING' && (
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                )}
                <span
                  className={`relative inline-flex rounded-full h-3.5 w-3.5 ${
                    gatewayState === 'RUNNING'
                      ? 'bg-emerald-500'
                      : gatewayState === 'STARTING' || gatewayState === 'STOPPING'
                      ? 'bg-amber-500'
                      : 'bg-red-500'
                  }`}
                ></span>
              </span>

              <div>
                <h2 className="font-bold text-base text-slate-100">
                  {gatewayState === 'RUNNING'
                    ? t.statusRunning
                    : gatewayState === 'STARTING'
                    ? t.starting
                    : gatewayState === 'STOPPING'
                    ? t.stopping
                    : t.statusStopped}
                </h2>
                <div className="text-[11px] font-mono text-slate-400">
                  {gatewayState === 'RUNNING'
                    ? `${t.listeningOn}http://${ipAddress}:${port}`
                    : 'HTTP Server Offline'}
                </div>
              </div>
            </div>

            <button
              onClick={onToggleGateway}
              disabled={gatewayState === 'STARTING' || gatewayState === 'STOPPING'}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition shadow-md ${
                gatewayState === 'RUNNING'
                  ? 'bg-red-600 hover:bg-red-500 text-white shadow-red-950/40'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-950/40'
              }`}
            >
              {gatewayState === 'RUNNING' ? (
                <>
                  <Square className="w-3.5 h-3.5 fill-current" /> {t.stopGateway}
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" /> {t.startGateway}
                </>
              )}
            </button>
          </div>

          <div className="pt-2 border-t border-slate-900 flex items-center justify-between text-xs">
            <span className="text-slate-400">
              {pairedDesktop ? (
                <span className="text-blue-400 font-medium">
                  {t.pairedWith} {pairedDesktop.computerName}
                </span>
              ) : (
                <span className="text-slate-500">{t.noDesktopPaired}</span>
              )}
            </span>
            <span className="text-[10px] text-slate-500 font-mono">v1.0.0 (API 35)</span>
          </div>
        </div>

        {/* 2x2 Metrics Grid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-slate-950/90 border border-slate-800/90 rounded-xl p-3.5 space-y-1">
            <div className="text-2xl font-black text-emerald-400 font-mono">{sentToday}</div>
            <div className="text-xs text-slate-400 font-medium">{t.sentToday}</div>
          </div>

          <div className="bg-slate-950/90 border border-slate-800/90 rounded-xl p-3.5 space-y-1">
            <div className="text-2xl font-black text-red-400 font-mono">{failedToday}</div>
            <div className="text-xs text-slate-400 font-medium">{t.failedToday}</div>
          </div>

          <div className="bg-slate-950/90 border border-slate-800/90 rounded-xl p-3.5 space-y-1">
            <div className="text-2xl font-black text-amber-400 font-mono">{pendingCount}</div>
            <div className="text-xs text-slate-400 font-medium">{t.pendingQueue}</div>
          </div>

          <div className="bg-slate-950/90 border border-slate-800/90 rounded-xl p-3.5 space-y-1">
            <div className="text-2xl font-black text-blue-400 font-mono">{totalSent}</div>
            <div className="text-xs text-slate-400 font-medium">{t.totalSent}</div>
          </div>
        </div>

        {/* SIM & Cellular Telephony Card */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-3">
          <h3 className="font-semibold text-xs text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Wifi className="w-3.5 h-3.5 text-blue-400" /> SIM & Telephony Status
          </h3>

          <div className="space-y-2 text-xs divide-y divide-slate-900">
            {sims.map((sim) => (
              <div key={sim.slot} className="pt-2 first:pt-0 flex items-center justify-between">
                <div>
                  <div className="font-medium text-slate-200">
                    Slot {sim.slot + 1}: {sim.operator}
                  </div>
                  <div className="text-[10px] text-slate-500">
                    {sim.type} • {sim.signalDbm} dBm
                  </div>
                </div>
                <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded font-mono">
                  Ready
                </span>
              </div>
            ))}

            <div className="pt-2 flex items-center justify-between text-xs">
              <span className="text-slate-400 flex items-center gap-1.5">
                <Battery className="w-3.5 h-3.5 text-slate-400" /> Battery
              </span>
              <span className="font-mono text-slate-200">{batteryPct}% (AC Charger)</span>
            </div>

            <div className="pt-2 flex items-center justify-between text-xs">
              <span className="text-slate-400">Local Wi-Fi IP</span>
              <span className="font-mono text-blue-400 font-semibold">{ipAddress}</span>
            </div>
          </div>
        </div>

        {/* Manual SMS Dispatch Testbed */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-3">
          <h3 className="font-semibold text-xs text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Send className="w-3.5 h-3.5 text-blue-400" /> {t.quickSend}
          </h3>

          <form onSubmit={handleSend} className="space-y-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">Recipient Number</label>
              <input
                type="text"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                placeholder={t.phonePlaceholder}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 font-mono focus:outline-hidden focus:border-blue-500"
              />
            </div>

            <div>
              <div className="flex items-center justify-between text-slate-400 mb-1">
                <label>Message Content</label>
                <span className="text-[10px] font-mono text-blue-400">
                  {charLength} {t.characters} • {segmentCount} {t.segments} ({isUnicode ? 'UCS-2' : 'GSM-7'})
                </span>
              </div>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder={t.messagePlaceholder}
                rows={2}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-200 focus:outline-hidden focus:border-blue-500 resize-none"
              />
            </div>

            <div className="flex items-center justify-between pt-1">
              <div className="flex items-center gap-2">
                <span className="text-slate-400">SIM:</span>
                <select
                  value={selectedSlot}
                  onChange={(e) => setSelectedSlot(parseInt(e.target.value))}
                  className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-slate-200"
                >
                  {sims.map((s) => (
                    <option key={s.slot} value={s.slot}>
                      Slot {s.slot + 1} ({s.operator})
                    </option>
                  ))}
                </select>
              </div>

              <button
                type="submit"
                disabled={gatewayState !== 'RUNNING'}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white rounded-lg font-semibold flex items-center gap-1.5 transition shadow-sm"
              >
                <Send className="w-3.5 h-3.5" />
                {t.sendSms}
              </button>
            </div>

            {gatewayState !== 'RUNNING' && (
              <p className="text-[11px] text-amber-400/90 text-center">
                Start the Gateway service above to enable SMS dispatching.
              </p>
            )}

            {quickSendFeedback && (
              <div
                className={`p-2 rounded-lg text-xs flex items-center gap-1.5 ${
                  quickSendFeedback.isError
                    ? 'bg-red-950/70 border border-red-800 text-red-300'
                    : 'bg-emerald-950/70 border border-emerald-800 text-emerald-300'
                }`}
              >
                {quickSendFeedback.isError ? (
                  <AlertCircle className="w-4 h-4 shrink-0" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                )}
                <span>{quickSendFeedback.msg}</span>
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};
