export interface Translations {
  appName: string;
  companyName: string;
  dashboard: string;
  logs: string;
  settings: string;
  pairing: string;
  startGateway: string;
  stopGateway: string;
  starting: string;
  stopping: string;
  statusRunning: string;
  statusStopped: string;
  statusConnected: string;
  statusOffline: string;
  listeningOn: string;
  noNetwork: string;
  sentToday: string;
  failedToday: string;
  pendingQueue: string;
  totalSent: string;
  simStatus: string;
  operator: string;
  signalStrength: string;
  battery: string;
  ipAddress: string;
  port: string;
  version: string;
  scanPrompt: string;
  pairingSuccess: string;
  pairedWith: string;
  noDesktopPaired: string;
  exportCsv: string;
  clearLogs: string;
  searchPlaceholder: string;
  portNotice: string;
  autoStartTitle: string;
  batteryOptTitle: string;
  saveSettings: string;
  quickSend: string;
  phonePlaceholder: string;
  messagePlaceholder: string;
  sendSms: string;
  characters: string;
  segments: string;
}

export const translations: Record<'en' | 'am', Translations> = {
  en: {
    appName: 'JM SMS Gateway',
    companyName: 'JM Technology',
    dashboard: 'Gateway Dashboard',
    logs: 'SMS & Event Logs',
    settings: 'Gateway Settings',
    pairing: 'Pair Desktop Connector',
    startGateway: 'Start Gateway',
    stopGateway: 'Stop Gateway',
    starting: 'Starting…',
    stopping: 'Stopping…',
    statusRunning: 'Running',
    statusStopped: 'Stopped',
    statusConnected: 'Connected',
    statusOffline: 'Offline',
    listeningOn: 'Listening at: ',
    noNetwork: 'No Wi-Fi / Local Network',
    sentToday: 'Sent Today',
    failedToday: 'Failed',
    pendingQueue: 'Pending Queue',
    totalSent: 'Total Sent',
    simStatus: 'SIM Status',
    operator: 'Operator',
    signalStrength: 'Signal Strength',
    battery: 'Battery',
    ipAddress: 'Local IP Address',
    port: 'Gateway Port',
    version: 'App Version',
    scanPrompt: 'Point camera at QR code on JM SMS Connector Desktop',
    pairingSuccess: 'Desktop paired successfully!',
    pairedWith: 'Paired Desktop: ',
    noDesktopPaired: 'No desktop paired — Tap pairing icon to pair',
    exportCsv: 'Export CSV',
    clearLogs: 'Clear Logs',
    searchPlaceholder: 'Search recipient, text, category…',
    portNotice: 'Changing port requires restarting the gateway service.',
    autoStartTitle: 'Auto-start on Boot',
    batteryOptTitle: 'Ignore Battery Optimization',
    saveSettings: 'Save Settings',
    quickSend: 'Manual SMS Test Dispatch',
    phonePlaceholder: '+251911223344 or 0911223344',
    messagePlaceholder: 'Type message body here (Amharic or English)…',
    sendSms: 'Dispatch SMS',
    characters: 'characters',
    segments: 'SMS segment(s)',
  },
  am: {
    appName: 'ጄኤም ኤስኤምኤስ ጌትዌይ',
    companyName: 'ጄኤም ቴክኖሎጂ',
    dashboard: 'የጌትዌይ ዳሽቦርድ',
    logs: 'የመልዕክት እና ሁነት ምዝገባዎች',
    settings: 'የጌትዌይ ማስተካከያዎች',
    pairing: 'ከዴስክቶፕ ጋር አገናኝ (Pair)',
    startGateway: 'ጌትዌይ አስጀምር',
    stopGateway: 'ጌትዌይ አቁም',
    starting: 'በመጀመር ላይ…',
    stopping: 'በማቆም ላይ…',
    statusRunning: 'በመስራት ላይ',
    statusStopped: 'ቆሟል',
    statusConnected: 'ተገናኝቷል',
    statusOffline: 'መስመር ውጭ',
    listeningOn: 'አድራሻ: ',
    noNetwork: 'ዋይፋይ ወይም የአካባቢ ኔትወርክ የለም',
    sentToday: 'ዛሬ የተላኩ',
    failedToday: 'ያልተሳኩ',
    pendingQueue: 'በመጠባበቅ ላይ',
    totalSent: 'አጠቃላይ የተላኩ',
    simStatus: 'የሲም ካርድ ሁኔታ',
    operator: 'ኦፕሬተር',
    signalStrength: 'የኔትወርክ ጥንካሬ',
    battery: 'ባትሪ',
    ipAddress: 'የአካባቢ IP አድራሻ',
    port: 'የጌትዌይ ፖርት',
    version: 'የመተግበሪያ ሥሪት',
    scanPrompt: 'ካሜራውን በዴስክቶፕ ኮኔክተሩ ላይ ወዳለው QR ኮድ ያነጣጥሩ',
    pairingSuccess: 'ከዴስክቶፕ ጋር በተሳካ ሁኔታ ተገናኝቷል!',
    pairedWith: 'የተገናኘ ዴስክቶፕ: ',
    noDesktopPaired: 'የተገናኘ ዴስክቶፕ የለም — ለማገናኘት የQR ምልክቱን ይጫኑ',
    exportCsv: 'CSV አውርድ',
    clearLogs: 'ምዝገባዎችን አጽዳ',
    searchPlaceholder: 'ስልክ፣ ጽሑፍ ወይም ምድብ ይፈልጉ…',
    portNotice: 'ፖርቱን መቀየር የጌትዌይ አገልግሎቱን ዳግም ማስጀመር ይፈልጋል።',
    autoStartTitle: 'ስልክ ሲበራ በራስ-ሰር ጀምር',
    batteryOptTitle: 'የባትሪ ቁጠባ ገደብን ዝለል',
    saveSettings: 'ቅንብሮችን መዝግብ',
    quickSend: 'የሙከራ ኤስኤምኤስ መላኪያ',
    phonePlaceholder: '+251911223344 ወይም 0911223344',
    messagePlaceholder: 'የመልዕክቱን ይዘት እዚህ ይጻፉ (በአማርኛ ወይም እንግሊዝኛ)…',
    sendSms: 'ኤስኤምኤስ ላክ',
    characters: 'ፊደላት',
    segments: 'የSMS ክፍልፋይ',
  },
};
