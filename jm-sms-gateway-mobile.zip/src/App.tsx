import React, { useState, useEffect } from 'react';
import { Smartphone, Laptop, FolderGit2, ClipboardCheck, Globe, RefreshCw, Server, ShieldCheck } from 'lucide-react';
import { GatewayState, GatewaySettings, PairedDesktop, SimCardInfo, SmsLog, SmsMessage } from './types/gateway';
import { PhoneFrame } from './components/PhoneFrame';
import { AndroidStatusTray } from './components/AndroidStatusTray';
import { DashboardView } from './components/DashboardView';
import { LogsView } from './components/LogsView';
import { SettingsModal } from './components/SettingsModal';
import { PairingModal } from './components/PairingModal';
import { DesktopSimulator } from './components/DesktopSimulator';
import { ProjectExplorer } from './components/ProjectExplorer';
import { translations } from './locales/translations';

export default function App() {
  const [activeTab, setActiveTab] = useState<'mobile' | 'desktop' | 'code' | 'report'>('mobile');
  const [activeMobileScreen, setActiveMobileScreen] = useState<'dashboard' | 'logs'>('dashboard');

  const [settings, setSettings] = useState<GatewaySettings>({
    port: 8080,
    maxRetries: 3,
    retryDelaySeconds: 5,
    autoStartOnBoot: true,
    ignoreBatteryOptimization: true,
    language: 'en',
    theme: 'default',
  });

  const [gatewayState, setGatewayState] = useState<GatewayState>('RUNNING');
  const [pairedDesktop, setPairedDesktop] = useState<PairedDesktop | null>({
    desktopId: 'DESKTOP-JM-CLIENT-01',
    computerName: 'Main-HQ-Server',
    pairingSecret: 'sec_desktop_demo_key',
    licenseId: 'LIC-JM-ENTERPRISE-2026',
    desktopHost: '192.168.1.10',
    desktopPort: 8080,
    isActive: true,
    pairedAt: Date.now() - 3600000,
    lastSeenAt: Date.now(),
  });

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isPairingOpen, setIsPairingOpen] = useState(false);

  const [sims] = useState<SimCardInfo[]>([
    { slot: 0, displayName: 'SIM 1', operator: 'Ethio telecom', signalDbm: -78, isReady: true, type: '4G LTE' },
    { slot: 1, displayName: 'SIM 2', operator: 'Safaricom ET', signalDbm: -85, isReady: true, type: '5G' },
  ]);

  const [logs, setLogs] = useState<SmsLog[]>([
    { id: '1', category: 'SERVER', level: 'INFO', message: 'NanoHTTPD Gateway listening on 192.168.1.50:8080', timestamp: Date.now() - 120000 },
    { id: '2', category: 'PAIRING', level: 'INFO', message: 'Authorized desktop paired: Main-HQ-Server', timestamp: Date.now() - 110000 },
    { id: '3', category: 'SMS', level: 'INFO', message: 'Delivered message to +251911223344 (1 part)', recipient: '+251911223344', status: 'DELIVERED', timestamp: Date.now() - 60000 },
  ]);

  const [messages, setMessages] = useState<SmsMessage[]>([]);
  const [sentToday, setSentToday] = useState(14);
  const [failedToday, setFailedToday] = useState(1);
  const [pendingCount, setPendingCount] = useState(0);
  const [totalSent, setTotalSent] = useState(189);
  const [activityRecreateKey, setActivityRecreateKey] = useState(0);

  // Duplicate guard cache (60s)
  const duplicateCache = React.useRef<Map<string, number>>(new Map());

  const addLog = (category: SmsLog['category'], level: SmsLog['level'], message: string, recipient?: string, status?: string) => {
    const newLog: SmsLog = {
      id: Math.random().toString(36).substring(2, 9),
      category,
      level,
      message,
      recipient,
      status,
      timestamp: Date.now(),
    };
    setLogs((prev) => [newLog, ...prev]);
  };

  const handleToggleGateway = () => {
    if (gatewayState === 'RUNNING') {
      setGatewayState('STOPPING');
      addLog('SERVER', 'INFO', 'Stopping gateway foreground service…');
      setTimeout(() => {
        setGatewayState('STOPPED');
        addLog('SERVER', 'INFO', 'Gateway HTTP server stopped.');
      }, 700);
    } else {
      setGatewayState('STARTING');
      addLog('SERVER', 'INFO', `Starting gateway on port ${settings.port}…`);
      setTimeout(() => {
        setGatewayState('RUNNING');
        addLog('SERVER', 'INFO', `Gateway active at http://192.168.1.50:${settings.port}`);
      }, 700);
    }
  };

  const handleQuickSendSms = (recipient: string, messageText: string, simSlot: number) => {
    if (gatewayState !== 'RUNNING') {
      return { success: false, error: 'Gateway HTTP server is stopped' };
    }

    // Check duplicate guard
    const hash = `${recipient}::${messageText}`;
    const now = Date.now();
    const lastSent = duplicateCache.current.get(hash);
    if (lastSent && now - lastSent < 60000) {
      addLog('SMS', 'WARNING', `Duplicate message rejected by DuplicateGuard: ${recipient}`, recipient, 'REJECTED');
      return { success: false, error: 'Duplicate request detected within 60s window (HTTP 409)' };
    }
    duplicateCache.current.set(hash, now);

    const isUnicode = Array.from(messageText).some((char) => char.charCodeAt(0) > 127);
    const maxSingle = isUnicode ? 70 : 160;
    const maxConcat = isUnicode ? 67 : 153;
    const segments = messageText.length <= maxSingle ? 1 : Math.ceil(messageText.length / maxConcat);

    const msgId = 'msg_' + Date.now();
    const newMsg: SmsMessage = {
      id: msgId,
      clientMessageId: msgId,
      recipient,
      messageBody: messageText,
      simSlot,
      status: 'PENDING',
      retryCount: 0,
      maxRetries: settings.maxRetries,
      createdAt: now,
      updatedAt: now,
      segments,
      isUnicode,
    };

    setMessages((prev) => [newMsg, ...prev]);
    setPendingCount((c) => c + 1);
    addLog('SMS', 'INFO', `Enqueued SMS to ${recipient} (${segments} parts via SIM ${simSlot + 1})`, recipient, 'PENDING');

    // Simulate sending via SmsManager
    setTimeout(() => {
      setMessages((prev) =>
        prev.map((m) => (m.id === msgId ? { ...m, status: 'SENDING' } : m))
      );
      addLog('SMS', 'INFO', `SmsManager dispatching to carrier for ${recipient}`, recipient, 'SENDING');

      setTimeout(() => {
        setMessages((prev) =>
          prev.map((m) => (m.id === msgId ? { ...m, status: 'DELIVERED' } : m))
        );
        setPendingCount((c) => Math.max(0, c - 1));
        setSentToday((s) => s + 1);
        setTotalSent((t) => t + 1);
        addLog('SMS', 'INFO', `Carrier confirmed delivery to ${recipient}`, recipient, 'DELIVERED');
      }, 1200);
    }, 800);

    return { success: true };
  };

  // Desktop Simulator API handlers
  const handleDesktopSms = (
    recipient: string,
    messageText: string,
    token: string,
    useNonce: boolean,
    nonce: string,
    timestamp: number
  ) => {
    if (gatewayState !== 'RUNNING') {
      return {
        statusCode: 503,
        responseBody: { success: false, error: 'Gateway HTTP server is currently stopped', errorCode: 503 },
      };
    }

    // Validate Auth
    const validSecret = pairedDesktop ? pairedDesktop.pairingSecret : 'sec_desktop_demo_key';
    if (!token || token.trim() !== validSecret) {
      addLog('SERVER', 'SECURITY', 'Unauthorized desktop request: Invalid Bearer token');
      return {
        statusCode: 401,
        responseBody: { success: false, error: 'Unauthorized: Invalid Bearer token', errorCode: 401 },
      };
    }

    const res = handleQuickSendSms(recipient, messageText, 0);
    if (!res.success) {
      return {
        statusCode: 409,
        responseBody: { success: false, error: res.error, errorCode: 409 },
      };
    }

    return {
      statusCode: 200,
      responseBody: {
        success: true,
        clientMessageId: 'desktop_' + Date.now(),
        status: 'PENDING',
        timestamp: Date.now(),
      },
    };
  };

  const handleDesktopHeartbeat = (token: string) => {
    if (gatewayState !== 'RUNNING') {
      return {
        statusCode: 503,
        responseBody: { success: false, error: 'Gateway offline' },
      };
    }
    const validSecret = pairedDesktop ? pairedDesktop.pairingSecret : 'sec_desktop_demo_key';
    if (!token || token.trim() !== validSecret) {
      return {
        statusCode: 401,
        responseBody: { success: false, error: 'Unauthorized heartbeat' },
      };
    }
    return {
      statusCode: 200,
      responseBody: {
        success: true,
        gatewayStatus: 'ONLINE',
        serverTime: Date.now(),
        pendingQueue: pendingCount,
        batteryLevel: '94% (AC)',
      },
    };
  };

  const handleDesktopStatus = () => {
    return {
      statusCode: 200,
      responseBody: {
        success: true,
        gatewayName: 'JM SMS Gateway Mobile',
        version: '1.0.0',
        status: gatewayState,
        ipAddress: '192.168.1.50',
        port: settings.port,
        pairedDesktop: pairedDesktop?.computerName || null,
        simCards: sims.map((s) => ({ slot: s.slot, operator: s.operator, ready: s.isReady })),
        sentToday,
        failedToday,
        pendingQueue: pendingCount,
        battery: '94% (Charging)',
      },
    };
  };

  return (
    <div className="flex flex-col h-screen w-full bg-slate-950 text-slate-100 font-sans overflow-hidden">
      {/* Top Application Header */}
      <header className="h-14 bg-slate-900 border-b border-slate-800 flex items-center justify-between px-5 shrink-0 z-20">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center font-bold text-white shadow-md shadow-blue-900/40">
            JM
          </div>
          <div>
            <h1 className="font-bold text-sm tracking-tight flex items-center gap-2">
              JM SMS Gateway Mobile
              <span className="text-[10px] font-mono font-medium px-2 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800">
                v1.0.0 • API 35
              </span>
            </h1>
            <p className="text-[11px] text-slate-400">
              JM Technology • Android SMS Gateway for JM SMS Connector
            </p>
          </div>
        </div>

        {/* Global Navigation Tabs */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('mobile')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
              activeTab === 'mobile'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Mobile Device (App)</span>
          </button>

          <button
            onClick={() => setActiveTab('desktop')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
              activeTab === 'desktop'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Laptop className="w-3.5 h-3.5" />
            <span>Desktop Connector Testbed</span>
          </button>

          <button
            onClick={() => setActiveTab('code')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
              activeTab === 'code'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FolderGit2 className="w-3.5 h-3.5" />
            <span>Android Studio Project</span>
          </button>

          <button
            onClick={() => setActiveTab('report')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
              activeTab === 'report'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ClipboardCheck className="w-3.5 h-3.5" />
            <span>Build & Audit Report</span>
          </button>
        </div>

        {/* Language Switch */}
        <div className="flex items-center gap-2">
          <button
            onClick={() =>
              setSettings((prev) => ({
                ...prev,
                language: prev.language === 'en' ? 'am' : 'en',
              }))
            }
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
          >
            <Globe className="w-3.5 h-3.5 text-blue-400" />
            <span>{settings.language === 'en' ? 'EN | አማርኛ' : 'አማርኛ | EN'}</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-hidden relative">
        {activeTab === 'mobile' && (
          <div className="h-full flex flex-col md:flex-row items-center justify-center p-4 gap-6 overflow-y-auto">
            {/* Phone Mockup Frame */}
            <div className="shrink-0 my-auto">
              <PhoneFrame>
                <div key={activityRecreateKey} className="flex flex-col h-full">
                  <AndroidStatusTray
                    gatewayState={gatewayState}
                    port={settings.port}
                    sentToday={sentToday}
                    batteryPct={94}
                    onStopGateway={() => setGatewayState('STOPPED')}
                    lang={settings.language}
                  />

                  <div className="flex-1 overflow-hidden">
                    {activeMobileScreen === 'dashboard' ? (
                      <DashboardView
                        gatewayState={gatewayState}
                        onToggleGateway={handleToggleGateway}
                        sentToday={sentToday}
                        failedToday={failedToday}
                        pendingCount={pendingCount}
                        totalSent={totalSent}
                        pairedDesktop={pairedDesktop}
                        port={settings.port}
                        ipAddress="192.168.1.50"
                        batteryPct={94}
                        sims={sims}
                        lang={settings.language}
                        onOpenLogs={() => setActiveMobileScreen('logs')}
                        onOpenSettings={() => setIsSettingsOpen(true)}
                        onOpenPairing={() => setIsPairingOpen(true)}
                        onQuickSendSms={handleQuickSendSms}
                      />
                    ) : (
                      <LogsView
                        logs={logs}
                        onBack={() => setActiveMobileScreen('dashboard')}
                        onClearLogs={() => setLogs([])}
                        lang={settings.language}
                      />
                    )}
                  </div>
                </div>
              </PhoneFrame>
            </div>

            {/* Side Controls & Known Issue Testing */}
            <div className="max-w-md space-y-4 text-xs">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
                <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  Known Issue #22 Verification Test
                </h3>
                <p className="text-slate-400 leading-relaxed">
                  In the original code, <code className="text-blue-300">MainActivity</code> maintained a local boolean for Start/Stop state, causing state drift and showing &ldquo;Start Gateway&rdquo; after activity recreation even when the foreground service was active.
                </p>
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Current Gateway Service State:</span>
                    <span className="font-mono font-bold text-emerald-400">{gatewayState}</span>
                  </div>
                  <button
                    onClick={() => {
                      setActivityRecreateKey((k) => k + 1);
                      addLog('SYSTEM', 'INFO', 'Simulated Activity recreation (Configuration change / rotation)');
                    }}
                    className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-semibold flex items-center justify-center gap-1.5 transition"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    Simulate Android Activity Recreation
                  </button>
                  <p className="text-[11px] text-slate-500">
                    Notice that after recreation, the UI maintains the true <code className="text-slate-400">GatewayConnectionState</code> without resetting!
                  </p>
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
                <h4 className="font-semibold text-slate-200">Gateway Network Details</h4>
                <div className="space-y-1 font-mono text-slate-400">
                  <div>Local URL: <span className="text-blue-400">http://192.168.1.50:{settings.port}</span></div>
                  <div>Service Type: <span className="text-slate-300">dataSync (Android 14+)</span></div>
                  <div>Paired Desktop: <span className="text-emerald-400">{pairedDesktop?.computerName || 'None'}</span></div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'desktop' && (
          <DesktopSimulator
            gatewayState={gatewayState}
            port={settings.port}
            ipAddress="192.168.1.50"
            pairedDesktop={pairedDesktop}
            onSendFromDesktop={handleDesktopSms}
            onHeartbeat={handleDesktopHeartbeat}
            onGetStatus={handleDesktopStatus}
          />
        )}

        {activeTab === 'code' && <ProjectExplorer />}

        {activeTab === 'report' && (
          <div className="h-full overflow-y-auto p-6 max-w-4xl mx-auto space-y-6 text-sm">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
              <h2 className="text-xl font-bold text-slate-100 pb-2 border-b border-slate-800 flex items-center justify-between">
                <span>JM SMS Gateway Mobile — Engineering & Packaging Audit</span>
                <span className="text-xs px-3 py-1 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono">
                  All 14 Modules Implemented
                </span>
              </h2>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono text-xs">
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-slate-500 text-[10px]">PACKAGE</div>
                  <div className="font-bold text-blue-400">com.jmtechnology.smsgateway</div>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-slate-500 text-[10px]">MIN / TARGET SDK</div>
                  <div className="font-bold text-slate-200">26 / 35</div>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-slate-500 text-[10px]">VERSION</div>
                  <div className="font-bold text-slate-200">1.0.0 (Code 1)</div>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-slate-500 text-[10px]">PROJECT DIR</div>
                  <div className="font-bold text-slate-200">JMSMSGatewayMobile/</div>
                </div>
              </div>

              <div className="space-y-3 pt-3">
                <h3 className="font-bold text-slate-200 text-sm">Main Features Verified:</h3>
                <ul className="space-y-2 text-xs text-slate-300">
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    <strong>1. Receiving SMS requests:</strong> Validates payload, recipient phone numbers, and authentication via <code className="text-blue-300 font-mono">GatewayHttpServer</code>.
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    <strong>2. SIM Telephony & SmsManager:</strong> Multi-slot SIM support with automatic UCS-2 (Amharic) and GSM 7-bit segmentation calculation.
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    <strong>3. Broadcast Status Receivers:</strong> <code className="text-blue-300 font-mono">SmsSentReceiver</code> and <code className="text-blue-300 font-mono">SmsDeliveredReceiver</code> handling pending, sent, delivered, and error codes.
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    <strong>4. Room Database:</strong> Full entity and DAO structure for <code className="text-blue-300 font-mono">SmsMessage</code>, <code className="text-blue-300 font-mono">SmsLog</code>, <code className="text-blue-300 font-mono">PairedDesktop</code>, and <code className="text-blue-300 font-mono">GatewaySettings</code>.
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    <strong>5. Foreground Service:</strong> <code className="text-blue-300 font-mono">GatewayForegroundService</code> configured with <code className="text-blue-300 font-mono">android:foregroundServiceType="dataSync"</code> for Android 14+ compliance.
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    <strong>6. State Drift Fix (#22):</strong> Single source of truth using <code className="text-blue-300 font-mono">GatewayConnectionState</code> singleton LiveData bound to service lifecycle.
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    <strong>7. Zero-Trust Security:</strong> Subnet restriction, Bearer token authentication, 5-minute sliding window Nonce replay protection, and 60s DuplicateGuard debounce.
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    <strong>8. QR Desktop Pairing:</strong> CameraX and ZXing barcode scanning pipeline with HMAC-SHA256 signature verification.
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    <strong>9. Bilingual Support:</strong> Complete English and native Amharic (<code className="text-blue-300 font-mono">res/values-am/strings.xml</code>) translations.
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    <strong>10. Log Export:</strong> CSV log export with <code className="text-blue-300 font-mono">FileProvider</code> sharing.
                  </li>
                </ul>
              </div>

              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                <div className="font-semibold text-xs text-amber-400">Environment & Compilation Notes</div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  The complete Android Studio project structure has been generated in <code className="text-blue-300">/JMSMSGatewayMobile</code> with all Java classes, Room DAOs/entities, Hilt configuration, layouts, and Gradle files (<code className="text-slate-300">settings.gradle</code>, <code className="text-slate-300">build.gradle</code>, <code className="text-slate-300">app/build.gradle</code>).
                  In this web execution container, the project can be synced and assembled directly in Android Studio via <code className="text-blue-300">./gradlew assembleDebug</code>.
                </p>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Modals */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSave={(newSettings) => {
          setSettings(newSettings);
          addLog('SYSTEM', 'INFO', `Gateway settings updated (Port: ${newSettings.port})`);
        }}
        lang={settings.language}
        onLanguageChange={(l) => setSettings((s) => ({ ...s, language: l }))}
      />

      <PairingModal
        isOpen={isPairingOpen}
        onClose={() => setIsPairingOpen(false)}
        pairedDesktop={pairedDesktop}
        onPairSuccess={(d) => {
          setPairedDesktop(d);
          addLog('PAIRING', 'INFO', `Paired with desktop: ${d.computerName}`);
        }}
        onUnpair={() => {
          setPairedDesktop(null);
          addLog('PAIRING', 'WARNING', 'Desktop un-paired from gateway');
        }}
        lang={settings.language}
      />
    </div>
  );
}
