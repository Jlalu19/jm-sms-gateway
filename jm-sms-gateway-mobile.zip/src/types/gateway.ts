export type GatewayState = 'STOPPED' | 'STARTING' | 'RUNNING' | 'STOPPING' | 'ERROR';

export type LogLevel = 'INFO' | 'WARNING' | 'ERROR' | 'SECURITY';
export type LogCategory = 'SMS' | 'SERVER' | 'PAIRING' | 'SYSTEM';
export type SmsStatus = 'PENDING' | 'SENDING' | 'SENT' | 'DELIVERED' | 'FAILED';

export interface SmsMessage {
  id: string;
  clientMessageId: string;
  recipient: string;
  messageBody: string;
  simSlot: number;
  status: SmsStatus;
  retryCount: number;
  maxRetries: number;
  failureReason?: string;
  createdAt: number;
  updatedAt: number;
  segments: number;
  isUnicode: boolean;
}

export interface SmsLog {
  id: string;
  category: LogCategory;
  level: LogLevel;
  message: string;
  recipient?: string;
  status?: string;
  timestamp: number;
}

export interface PairedDesktop {
  desktopId: string;
  computerName: string;
  pairingSecret: string;
  licenseId?: string;
  desktopHost: string;
  desktopPort: number;
  isActive: boolean;
  pairedAt: number;
  lastSeenAt: number;
}

export interface GatewaySettings {
  port: number;
  maxRetries: number;
  retryDelaySeconds: number;
  autoStartOnBoot: boolean;
  ignoreBatteryOptimization: boolean;
  language: 'en' | 'am';
  theme: 'light' | 'dark' | 'default';
}

export interface SimCardInfo {
  slot: number;
  displayName: string;
  operator: string;
  signalDbm: number;
  isReady: boolean;
  type: string;
}
