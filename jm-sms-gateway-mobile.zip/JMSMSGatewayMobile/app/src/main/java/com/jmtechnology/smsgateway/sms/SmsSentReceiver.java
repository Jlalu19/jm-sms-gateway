package com.jmtechnology.smsgateway.sms;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;
import com.jmtechnology.smsgateway.core.Constants;
import com.jmtechnology.smsgateway.data.db.AppDatabase;
import com.jmtechnology.smsgateway.data.db.entities.SmsMessageEntity;
import com.jmtechnology.smsgateway.data.repository.LogRepository;
import com.jmtechnology.smsgateway.data.repository.SmsQueueRepository;
import java.util.concurrent.Executors;

public class SmsSentReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Constants.ACTION_SMS_SENT.equals(intent.getAction())) return;

        long messageId = intent.getLongExtra(Constants.EXTRA_MESSAGE_ID, -1);
        int partIndex = intent.getIntExtra(Constants.EXTRA_PART_INDEX, 0);
        int totalParts = intent.getIntExtra(Constants.EXTRA_TOTAL_PARTS, 1);
        int resultCode = getResultCode();

        Executors.newSingleThreadExecutor().execute(() -> {
            AppDatabase db = AppDatabase.getInstance(context);
            SmsMessageEntity entity = db.smsMessageDao().getById(messageId);
            if (entity == null) return;

            if (resultCode == Activity.RESULT_OK) {
                // If this is the last part, mark as SENT
                if (partIndex >= totalParts - 1) {
                    db.smsMessageDao().updateStatus(messageId, "SENT", System.currentTimeMillis(), null);
                    db.smsLogDao().insert(createLog("SMS", "INFO", "Message sent successfully to " + entity.getRecipient(), entity.getRecipient(), "SENT"));
                }
            } else {
                String failureReason = getErrorDescription(resultCode);
                int retry = entity.getRetryCount() + 1;
                if (retry < entity.getMaxRetries()) {
                    entity.setRetryCount(retry);
                    entity.setStatus("PENDING");
                    db.smsMessageDao().update(entity);
                    db.smsLogDao().insert(createLog("SMS", "WARNING", "Send failed (" + failureReason + "), retry " + retry + "/" + entity.getMaxRetries(), entity.getRecipient(), "RETRYING"));
                } else {
                    db.smsMessageDao().updateStatus(messageId, "FAILED", System.currentTimeMillis(), failureReason);
                    db.smsLogDao().insert(createLog("SMS", "ERROR", "Send failed permanently: " + failureReason, entity.getRecipient(), "FAILED"));
                }
            }
        });
    }

    private String getErrorDescription(int resultCode) {
        switch (resultCode) {
            case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                return "Generic failure";
            case SmsManager.RESULT_ERROR_RADIO_OFF:
                return "Radio turned off (Airplane mode)";
            case SmsManager.RESULT_ERROR_NULL_PDU:
                return "Null PDU";
            case SmsManager.RESULT_ERROR_NO_SERVICE:
                return "No cellular service";
            default:
                return "Error code: " + resultCode;
        }
    }

    private com.jmtechnology.smsgateway.data.db.entities.SmsLogEntity createLog(String cat, String lvl, String msg, String recipient, String status) {
        com.jmtechnology.smsgateway.data.db.entities.SmsLogEntity log = new com.jmtechnology.smsgateway.data.db.entities.SmsLogEntity();
        log.setCategory(cat);
        log.setLevel(lvl);
        log.setMessage(msg);
        log.setRecipient(recipient);
        log.setStatus(status);
        log.setTimestamp(System.currentTimeMillis());
        return log;
    }
}
