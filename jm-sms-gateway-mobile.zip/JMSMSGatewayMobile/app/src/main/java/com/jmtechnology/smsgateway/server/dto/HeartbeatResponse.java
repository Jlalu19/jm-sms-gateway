package com.jmtechnology.smsgateway.server.dto;

import com.google.gson.annotations.SerializedName;

public class HeartbeatResponse {
    @SerializedName("success")
    public boolean success = true;

    @SerializedName("gatewayStatus")
    public String gatewayStatus = "ONLINE";

    @SerializedName("serverTime")
    public long serverTime = System.currentTimeMillis();

    @SerializedName("pendingQueue")
    public int pendingQueue;

    @SerializedName("batteryLevel")
    public String batteryLevel;
}
