package com.jmtechnology.smsgateway.service;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import androidx.annotation.Nullable;
import com.jmtechnology.smsgateway.core.Constants;
import com.jmtechnology.smsgateway.core.NetworkUtils;
import com.jmtechnology.smsgateway.data.repository.GatewaySettingsRepository;
import com.jmtechnology.smsgateway.data.repository.LogRepository;
import com.jmtechnology.smsgateway.data.repository.SmsQueueRepository;
import com.jmtechnology.smsgateway.monitoring.GatewayConnectionState;
import com.jmtechnology.smsgateway.queue.QueueScheduler;
import com.jmtechnology.smsgateway.server.GatewayHttpServer;
import dagger.hilt.android.AndroidEntryPoint;
import javax.inject.Inject;

@AndroidEntryPoint
public class GatewayForegroundService extends Service {

    @Inject
    GatewayHttpServer httpServer;

    @Inject
    GatewayConnectionState connectionState;

    @Inject
    GatewaySettingsRepository settingsRepository;

    @Inject
    SmsQueueRepository smsQueueRepository;

    @Inject
    LogRepository logRepository;

    @Inject
    QueueScheduler queueScheduler;

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;

        if (Constants.ACTION_STOP_GATEWAY.equals(action)) {
            stopGateway();
            stopSelf();
            return START_NOT_STICKY;
        }

        startGateway();
        return START_STICKY;
    }

    private void startGateway() {
        try {
            connectionState.setState(GatewayConnectionState.State.STARTING);
            int port = settingsRepository.getPort();
            connectionState.setActivePort(port);

            Notification notification = NotificationHelper.buildServiceNotification(
                    this,
                    port,
                    smsQueueRepository.getSentTodayCount()
            );

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                        Constants.NOTIFICATION_SERVICE_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                );
            } else {
                startForeground(Constants.NOTIFICATION_SERVICE_ID, notification);
            }

            if (!httpServer.isAlive()) {
                httpServer.start();
            }

            String url = "http://" + NetworkUtils.getLocalIpAddress() + ":" + port;
            connectionState.setServerUrl(url);
            connectionState.setState(GatewayConnectionState.State.RUNNING);

            logRepository.logInfo("SERVER", "Gateway started on port " + port + " (" + url + ")");
            queueScheduler.schedulePeriodicQueueWorker();
        } catch (Exception e) {
            connectionState.setState(GatewayConnectionState.State.ERROR);
            connectionState.setErrorMessage(e.getMessage());
            logRepository.logError("SERVER", "Failed to start HTTP server: " + e.getMessage());
            stopSelf();
        }
    }

    private void stopGateway() {
        connectionState.setState(GatewayConnectionState.State.STOPPING);
        try {
            if (httpServer != null && httpServer.isAlive()) {
                httpServer.stop();
            }
            logRepository.logInfo("SERVER", "Gateway server stopped");
        } catch (Exception ignored) {
        }
        connectionState.setState(GatewayConnectionState.State.STOPPED);
        stopForeground(true);
    }

    @Override
    public void onDestroy() {
        stopGateway();
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
