package com.jmtechnology.smsgateway.data.db;

public class StatusEnums {
    public enum MessageStatus {
        PENDING,
        SENDING,
        SENT,
        DELIVERED,
        FAILED
    }

    public enum LogLevel {
        INFO,
        WARNING,
        ERROR,
        SECURITY
    }

    public enum LogCategory {
        SMS,
        SERVER,
        PAIRING,
        SYSTEM
    }
}
