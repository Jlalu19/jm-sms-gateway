package com.jmtechnology.smsgateway.security;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class NonceCache {
    private static final long NONCE_VALIDITY_WINDOW_MS = 5 * 60 * 1000; // 5 minutes
    private final Map<String, Long> usedNonces = new ConcurrentHashMap<>();

    @Inject
    public NonceCache() {}

    public synchronized boolean validateAndRecord(String nonce, long timestamp) {
        long now = System.currentTimeMillis();
        // Check timestamp drift
        if (Math.abs(now - timestamp) > NONCE_VALIDITY_WINDOW_MS) {
            return false;
        }

        // Clean expired nonces
        usedNonces.entrySet().removeIf(entry -> now - entry.getValue() > NONCE_VALIDITY_WINDOW_MS);

        // Check replay
        if (usedNonces.containsKey(nonce)) {
            return false;
        }

        usedNonces.put(nonce, now);
        return true;
    }
}
