package com.jmtechnology.smsgateway.server;

import com.google.gson.Gson;
import com.jmtechnology.smsgateway.data.db.entities.SmsMessageEntity;
import com.jmtechnology.smsgateway.data.repository.GatewaySettingsRepository;
import com.jmtechnology.smsgateway.data.repository.LogRepository;
import com.jmtechnology.smsgateway.data.repository.SmsQueueRepository;
import com.jmtechnology.smsgateway.monitoring.DeviceStatusProvider;
import com.jmtechnology.smsgateway.queue.QueueScheduler;
import com.jmtechnology.smsgateway.security.SecureCredentialStore;
import com.jmtechnology.smsgateway.server.dto.ErrorResponse;
import com.jmtechnology.smsgateway.server.dto.GatewayStatusResponse;
import com.jmtechnology.smsgateway.server.dto.HeartbeatResponse;
import com.jmtechnology.smsgateway.server.dto.SmsSendRequest;
import com.jmtechnology.smsgateway.server.dto.SmsStatusResponse;
import com.jmtechnology.smsgateway.sms.DuplicateGuard;
import fi.iki.elonen.NanoHTTPD;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class GatewayHttpServer extends NanoHTTPD {
    private final AuthMiddleware authMiddleware;
    private final SmsQueueRepository smsQueueRepository;
    private final LogRepository logRepository;
    private final DeviceStatusProvider deviceStatusProvider;
    private final GatewaySettingsRepository settingsRepository;
    private final QueueScheduler queueScheduler;
    private final DuplicateGuard duplicateGuard;
    private final SecureCredentialStore credentialStore;
    private final Gson gson;

    @Inject
    public GatewayHttpServer(
            AuthMiddleware authMiddleware,
            SmsQueueRepository smsQueueRepository,
            LogRepository logRepository,
            DeviceStatusProvider deviceStatusProvider,
            GatewaySettingsRepository settingsRepository,
            QueueScheduler queueScheduler,
            DuplicateGuard duplicateGuard,
            SecureCredentialStore credentialStore,
            Gson gson) {
        super(settingsRepository.getPort());
        this.authMiddleware = authMiddleware;
        this.smsQueueRepository = smsQueueRepository;
        this.logRepository = logRepository;
        this.deviceStatusProvider = deviceStatusProvider;
        this.settingsRepository = settingsRepository;
        this.queueScheduler = queueScheduler;
        this.duplicateGuard = duplicateGuard;
        this.credentialStore = credentialStore;
        this.gson = gson;
    }

    @Override
    public Response serve(IHTTPSession session) {
        try {
            AuthMiddleware.AuthResult authResult = authMiddleware.authenticate(session);
            if (!authResult.isAuthorized) {
                return jsonResponse(Response.Status.lookup(authResult.statusCode),
                        new ErrorResponse(authResult.errorMessage, authResult.statusCode));
            }

            String uri = session.getUri();
            Method method = session.getMethod();

            if ("/api/v1/status".equals(uri) && method == Method.GET) {
                return handleStatus();
            } else if ("/api/v1/sms/send".equals(uri) && method == Method.POST) {
                return handleSendSms(session);
            } else if ("/api/v1/sms/status".equals(uri) && method == Method.GET) {
                return handleSmsStatus(session);
            } else if ("/api/v1/heartbeat".equals(uri) && method == Method.POST) {
                return handleHeartbeat();
            }

            return jsonResponse(Response.Status.NOT_FOUND, new ErrorResponse("Endpoint not found", 404));
        } catch (Exception e) {
            logRepository.logError("SERVER", "Unhandled server exception: " + e.getMessage());
            return jsonResponse(Response.Status.INTERNAL_ERROR, new ErrorResponse("Internal server error: " + e.getMessage(), 500));
        }
    }

    private Response handleStatus() {
        GatewayStatusResponse response = new GatewayStatusResponse();
        response.status = "RUNNING";
        response.ipAddress = deviceStatusProvider.getIpAddress();
        response.port = settingsRepository.getPort();
        response.pairedDesktop = credentialStore.getPairedDesktopId();
        response.sentToday = smsQueueRepository.getSentTodayCount();
        response.failedToday = smsQueueRepository.getFailedTodayCount();
        response.pendingQueue = smsQueueRepository.getPendingCount();
        response.battery = deviceStatusProvider.getBatteryStatus();
        response.version = deviceStatusProvider.getAppVersion();

        List<DeviceStatusProvider.SimInfo> sims = deviceStatusProvider.getSimCards();
        List<GatewayStatusResponse.SimInfoResponse> simResponses = new ArrayList<>();
        for (DeviceStatusProvider.SimInfo s : sims) {
            simResponses.add(new GatewayStatusResponse.SimInfoResponse(s.slotIndex, s.carrierName, s.isReady));
        }
        response.simCards = simResponses;

        return jsonResponse(Response.Status.OK, response);
    }

    private Response handleSendSms(IHTTPSession session) {
        try {
            Map<String, String> files = new HashMap<>();
            session.parseBody(files);
            String postData = files.get("postData");

            if (postData == null || postData.trim().isEmpty()) {
                return jsonResponse(Response.Status.BAD_REQUEST, new ErrorResponse("Empty request payload", 400));
            }

            SmsSendRequest request = gson.fromJson(postData, SmsSendRequest.class);
            if (request == null || request.recipient == null || request.recipient.trim().isEmpty() ||
                    request.message == null || request.message.trim().isEmpty()) {
                return jsonResponse(Response.Status.BAD_REQUEST, new ErrorResponse("Missing recipient or message", 400));
            }

            if (request.clientMessageId == null || request.clientMessageId.trim().isEmpty()) {
                request.clientMessageId = "msg_" + System.currentTimeMillis();
            }

            // Check Duplicate Guard
            if (duplicateGuard.isDuplicate(request.recipient, request.message)) {
                return jsonResponse(Response.Status.BAD_REQUEST, new ErrorResponse("Duplicate message detected within debounce window", 409));
            }
            duplicateGuard.recordSent(request.recipient, request.message);

            // Enqueue message
            int maxRetries = settingsRepository.getSettingsSync().getMaxRetries();
            long rowId = smsQueueRepository.enqueueMessage(
                    request.clientMessageId,
                    request.recipient,
                    request.message,
                    request.simSlot,
                    maxRetries
            );

            logRepository.logSms(request.recipient, "Message enqueued (ID: " + request.clientMessageId + ")", "PENDING");

            // Trigger worker scheduler immediately
            queueScheduler.triggerImmediateSync();

            return jsonResponse(Response.Status.OK, new SmsStatusResponse(true, request.clientMessageId, "PENDING", null));
        } catch (Exception e) {
            logRepository.logError("SMS", "Failed to process send request: " + e.getMessage());
            return jsonResponse(Response.Status.BAD_REQUEST, new ErrorResponse("Failed to parse request: " + e.getMessage(), 400));
        }
    }

    private Response handleSmsStatus(IHTTPSession session) {
        Map<String, List<String>> params = session.getParameters();
        List<String> idList = params.get("id");
        if (idList == null || idList.isEmpty()) {
            return jsonResponse(Response.Status.BAD_REQUEST, new ErrorResponse("Missing 'id' parameter", 400));
        }

        String clientMessageId = idList.get(0);
        SmsMessageEntity msg = smsQueueRepository.getMessageByClientId(clientMessageId);
        if (msg == null) {
            return jsonResponse(Response.Status.NOT_FOUND, new ErrorResponse("Message not found", 404));
        }

        return jsonResponse(Response.Status.OK, new SmsStatusResponse(
                "SENT".equals(msg.getStatus()) || "DELIVERED".equals(msg.getStatus()),
                msg.getClientMessageId(),
                msg.getStatus(),
                msg.getFailureReason()
        ));
    }

    private Response handleHeartbeat() {
        HeartbeatResponse response = new HeartbeatResponse();
        response.gatewayStatus = "ONLINE";
        response.serverTime = System.currentTimeMillis();
        response.pendingQueue = smsQueueRepository.getPendingCount();
        response.batteryLevel = deviceStatusProvider.getBatteryStatus();
        return jsonResponse(Response.Status.OK, response);
    }

    private Response jsonResponse(Response.IStatus status, Object data) {
        String json = gson.toJson(data);
        Response response = newFixedLengthResponse(status, "application/json", json);
        response.addHeader("Access-Control-Allow-Origin", "*");
        response.addHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Nonce, X-Timestamp");
        return response;
    }
}
