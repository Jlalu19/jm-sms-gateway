package com.jmtechnology.smsgateway.data.repository;

import androidx.lifecycle.LiveData;
import com.jmtechnology.smsgateway.core.AppExecutors;
import com.jmtechnology.smsgateway.data.db.dao.SmsLogDao;
import com.jmtechnology.smsgateway.data.db.entities.SmsLogEntity;
import java.util.List;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class LogRepository {
    private final SmsLogDao smsLogDao;
    private final AppExecutors appExecutors;

    @Inject
    public LogRepository(SmsLogDao smsLogDao, AppExecutors appExecutors) {
        this.smsLogDao = smsLogDao;
        this.appExecutors = appExecutors;
    }

    public void log(String category, String level, String message, String recipient, String status) {
        appExecutors.diskIO().execute(() -> {
            SmsLogEntity logEntity = new SmsLogEntity();
            logEntity.setCategory(category);
            logEntity.setLevel(level);
            logEntity.setMessage(message);
            logEntity.setRecipient(recipient);
            logEntity.setStatus(status);
            logEntity.setTimestamp(System.currentTimeMillis());
            smsLogDao.insert(logEntity);
        });
    }

    public void logInfo(String category, String message) {
        log(category, "INFO", message, null, null);
    }

    public void logError(String category, String message) {
        log(category, "ERROR", message, null, null);
    }

    public void logSms(String recipient, String message, String status) {
        log("SMS", "INFO", message, recipient, status);
    }

    public LiveData<List<SmsLogEntity>> getRecentLogs(int limit) {
        return smsLogDao.observeRecentLogs(limit);
    }

    public List<SmsLogEntity> getRecentLogsSync(int limit) {
        return smsLogDao.getRecentLogsSync(limit);
    }

    public List<SmsLogEntity> searchLogs(String query, int limit) {
        return smsLogDao.searchLogs(query, limit);
    }

    public void clearAllLogs() {
        appExecutors.diskIO().execute(smsLogDao::clearAllLogs);
    }
}
