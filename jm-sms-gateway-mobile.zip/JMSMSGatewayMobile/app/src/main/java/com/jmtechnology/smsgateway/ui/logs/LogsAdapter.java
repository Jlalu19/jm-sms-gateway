package com.jmtechnology.smsgateway.ui.logs;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.jmtechnology.smsgateway.R;
import com.jmtechnology.smsgateway.data.db.entities.SmsLogEntity;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class LogsAdapter extends RecyclerView.Adapter<LogsAdapter.LogViewHolder> {

    private final List<SmsLogEntity> logs = new ArrayList<>();
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());

    public void setLogs(List<SmsLogEntity> newLogs) {
        logs.clear();
        if (newLogs != null) {
            logs.addAll(newLogs);
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public LogViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_log, parent, false);
        return new LogViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LogViewHolder holder, int position) {
        SmsLogEntity log = logs.get(position);
        holder.tvRecipient.setText(log.getRecipient() != null ? log.getRecipient() : "[" + log.getCategory() + "]");
        holder.tvMessage.setText(log.getMessage());
        holder.tvTimestamp.setText(dateFormat.format(new Date(log.getTimestamp())));
        holder.tvStatus.setText(log.getStatus() != null ? log.getStatus() : log.getLevel());

        if ("SENT".equalsIgnoreCase(log.getStatus()) || "DELIVERED".equalsIgnoreCase(log.getStatus())) {
            holder.tvStatus.setTextColor(Color.parseColor("#10B981"));
        } else if ("FAILED".equalsIgnoreCase(log.getStatus()) || "ERROR".equalsIgnoreCase(log.getLevel())) {
            holder.tvStatus.setTextColor(Color.parseColor("#EF4444"));
        } else if ("WARNING".equalsIgnoreCase(log.getLevel()) || "RETRYING".equalsIgnoreCase(log.getStatus())) {
            holder.tvStatus.setTextColor(Color.parseColor("#F59E0B"));
        } else {
            holder.tvStatus.setTextColor(Color.parseColor("#0F52BA"));
        }
    }

    @Override
    public int getItemCount() {
        return logs.size();
    }

    static class LogViewHolder extends RecyclerView.ViewHolder {
        TextView tvRecipient;
        TextView tvMessage;
        TextView tvTimestamp;
        TextView tvStatus;

        LogViewHolder(@NonNull View itemView) {
            super(itemView);
            tvRecipient = itemView.findViewById(R.id.tvLogRecipient);
            tvMessage = itemView.findViewById(R.id.tvLogMessage);
            tvTimestamp = itemView.findViewById(R.id.tvLogTimestamp);
            tvStatus = itemView.findViewById(R.id.tvLogStatus);
        }
    }
}
