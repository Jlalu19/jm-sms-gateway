package com.jmtechnology.smsgateway.security;

import java.security.SecureRandom;
import java.util.Base64;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class TokenManager {
    private final SecureCredentialStore credentialStore;
    private final SecureRandom secureRandom = new SecureRandom();

    @Inject
    public TokenManager(SecureCredentialStore credentialStore) {
        this.credentialStore = credentialStore;
    }

    public String generateToken() {
        byte[] randomBytes = new byte[32];
        secureRandom.nextBytes(randomBytes);
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(randomBytes);
        credentialStore.saveAuthToken(token);
        return token;
    }

    public boolean validateToken(String bearerHeader) {
        if (bearerHeader == null || !bearerHeader.startsWith("Bearer ")) {
            return false;
        }
        String token = bearerHeader.substring(7).trim();
        String storedToken = credentialStore.getAuthToken();
        if (storedToken != null && storedToken.equals(token)) {
            return true;
        }
        String pairedSecret = credentialStore.getPairedSecret();
        return pairedSecret != null && pairedSecret.equals(token);
    }
}
