package com.jmtechnology.smsgateway.data.repository;

import androidx.lifecycle.LiveData;
import com.jmtechnology.smsgateway.core.AppExecutors;
import com.jmtechnology.smsgateway.data.db.dao.SmsMessageDao;
import com.jmtechnology.smsgateway.data.db.entities.SmsMessageEntity;
import java.util.Calendar;
import java.util.List;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class SmsQueueRepository {
    private final SmsMessageDao smsMessageDao;
    private final AppExecutors appExecutors;

    @Inject
    public SmsQueueRepository(SmsMessageDao smsMessageDao, AppExecutors appExecutors) {
        this.smsMessageDao = smsMessageDao;
        this.appExecutors = appExecutors;
    }

    public long enqueueMessage(String clientMessageId, String recipient, String messageBody, int simSlot, int maxRetries) {
        SmsMessageEntity entity = new SmsMessageEntity();
        entity.setClientMessageId(clientMessageId);
        entity.setRecipient(recipient);
        entity.setMessageBody(messageBody);
        entity.setSimSlot(simSlot);
        entity.setMaxRetries(maxRetries);
        entity.setStatus("PENDING");
        entity.setCreatedAt(System.currentTimeMillis());
        entity.setUpdatedAt(System.currentTimeMillis());
        return smsMessageDao.insert(entity);
    }

    public SmsMessageEntity getMessageById(long id) {
        return smsMessageDao.getById(id);
    }

    public SmsMessageEntity getMessageByClientId(String clientMessageId) {
        return smsMessageDao.getByClientMessageId(clientMessageId);
    }

    public List<SmsMessageEntity> getPendingMessages() {
        return smsMessageDao.getPendingMessages();
    }

    public void updateMessageStatus(long id, String status, String failureReason) {
        appExecutors.diskIO().execute(() -> {
            smsMessageDao.updateStatus(id, status, System.currentTimeMillis(), failureReason);
        });
    }

    public int getSentTodayCount() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return smsMessageDao.countSentSince(cal.getTimeInMillis());
    }

    public int getFailedTodayCount() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return smsMessageDao.countFailedSince(cal.getTimeInMillis());
    }

    public int getPendingCount() {
        return smsMessageDao.countPending();
    }

    public int getTotalSentCount() {
        return smsMessageDao.countTotalSent();
    }

    public LiveData<Integer> observePendingCount() {
        return smsMessageDao.observePending();
    }

    public LiveData<Integer> observeTotalSentCount() {
        return smsMessageDao.observeTotalSent();
    }
}
