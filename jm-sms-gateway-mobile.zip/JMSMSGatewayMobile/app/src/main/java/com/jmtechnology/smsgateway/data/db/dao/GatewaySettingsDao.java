package com.jmtechnology.smsgateway.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;
import com.jmtechnology.smsgateway.data.db.entities.GatewaySettingsEntity;

@Dao
public interface GatewaySettingsDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertOrUpdate(GatewaySettingsEntity settings);

    @Update
    void update(GatewaySettingsEntity settings);

    @Query("SELECT * FROM gateway_settings WHERE id = 1 LIMIT 1")
    GatewaySettingsEntity getSettings();

    @Query("SELECT * FROM gateway_settings WHERE id = 1 LIMIT 1")
    LiveData<GatewaySettingsEntity> observeSettings();
}
