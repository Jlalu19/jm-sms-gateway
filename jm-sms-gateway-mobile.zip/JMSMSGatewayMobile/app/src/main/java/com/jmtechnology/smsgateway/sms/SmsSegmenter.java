package com.jmtechnology.smsgateway.sms;

import android.telephony.SmsMessage;
import java.util.ArrayList;

public class SmsSegmenter {

    public static class SegmentInfo {
        public final int segmentCount;
        public final boolean isUnicode;
        public final int charsRemainingInSegment;

        public SegmentInfo(int segmentCount, boolean isUnicode, int charsRemainingInSegment) {
            this.segmentCount = segmentCount;
            this.isUnicode = isUnicode;
            this.charsRemainingInSegment = charsRemainingInSegment;
        }
    }

    public static SegmentInfo calculateSegments(String text) {
        if (text == null || text.isEmpty()) {
            return new SegmentInfo(0, false, 0);
        }

        try {
            int[] params = SmsMessage.calculateLength(text, false);
            // params[0] = num segments
            // params[1] = code units used
            // params[2] = code units remaining until next segment
            // params[3] = encoding (1 = 7-bit, 3 = 16-bit unicode)
            int msgCount = params[0];
            int remaining = params[2];
            boolean isUnicode = (params[3] == 3);
            return new SegmentInfo(msgCount, isUnicode, remaining);
        } catch (Exception e) {
            // Fallback manual check for unicode (e.g. Amharic chars)
            boolean unicode = false;
            for (char c : text.toCharArray()) {
                if (c > 127) {
                    unicode = true;
                    break;
                }
            }
            int maxSingle = unicode ? 70 : 160;
            int maxConcat = unicode ? 67 : 153;
            int len = text.length();
            int count = (len <= maxSingle) ? 1 : (int) Math.ceil((double) len / maxConcat);
            return new SegmentInfo(count, unicode, 0);
        }
    }
}
