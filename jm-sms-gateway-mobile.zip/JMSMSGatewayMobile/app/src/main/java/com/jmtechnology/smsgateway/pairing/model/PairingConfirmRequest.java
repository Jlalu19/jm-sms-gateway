package com.jmtechnology.smsgateway.pairing.model;

import com.google.gson.annotations.SerializedName;

public class PairingConfirmRequest {
    @SerializedName("desktopId")
    public String desktopId;

    @SerializedName("gatewayHost")
    public String gatewayHost;

    @SerializedName("gatewayPort")
    public int gatewayPort;

    @SerializedName("deviceModel")
    public String deviceModel;

    @SerializedName("signature")
    public String signature;
}
