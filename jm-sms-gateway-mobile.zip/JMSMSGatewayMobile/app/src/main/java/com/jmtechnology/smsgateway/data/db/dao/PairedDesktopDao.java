package com.jmtechnology.smsgateway.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;
import com.jmtechnology.smsgateway.data.db.entities.PairedDesktopEntity;
import java.util.List;

@Dao
public interface PairedDesktopDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertOrUpdate(PairedDesktopEntity desktop);

    @Update
    void update(PairedDesktopEntity desktop);

    @Query("SELECT * FROM paired_desktops WHERE desktopId = :desktopId LIMIT 1")
    PairedDesktopEntity getByDesktopId(String desktopId);

    @Query("SELECT * FROM paired_desktops WHERE isActive = 1 LIMIT 1")
    PairedDesktopEntity getActiveDesktop();

    @Query("SELECT * FROM paired_desktops WHERE isActive = 1 LIMIT 1")
    LiveData<PairedDesktopEntity> observeActiveDesktop();

    @Query("SELECT * FROM paired_desktops ORDER BY pairedAt DESC")
    List<PairedDesktopEntity> getAll();

    @Query("UPDATE paired_desktops SET isActive = 0 WHERE desktopId = :desktopId")
    void revokeDesktop(String desktopId);

    @Query("UPDATE paired_desktops SET lastSeenAt = :timestamp WHERE desktopId = :desktopId")
    void updateLastSeen(String desktopId, long timestamp);
}
