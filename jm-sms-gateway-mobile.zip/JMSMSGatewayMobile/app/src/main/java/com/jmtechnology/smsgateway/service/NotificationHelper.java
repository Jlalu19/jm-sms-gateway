package com.jmtechnology.smsgateway.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.jmtechnology.smsgateway.R;
import com.jmtechnology.smsgateway.core.Constants;
import com.jmtechnology.smsgateway.ui.MainActivity;

public class NotificationHelper {

    public static void createNotificationChannels(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    Constants.NOTIFICATION_CHANNEL_ID,
                    context.getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription(context.getString(R.string.notification_channel_desc));
            channel.setShowBadge(false);

            NotificationManager manager = context.getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    public static Notification buildServiceNotification(Context context, int port, int sentToday) {
        Intent openAppIntent = new Intent(context, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pendingOpen = PendingIntent.getActivity(context, 0, openAppIntent, flags);

        Intent stopIntent = new Intent(context, GatewayForegroundService.class);
        stopIntent.setAction(Constants.ACTION_STOP_GATEWAY);
        PendingIntent pendingStop = PendingIntent.getService(context, 1, stopIntent, flags);

        return new NotificationCompat.Builder(context, Constants.NOTIFICATION_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle(context.getString(R.string.notification_running_title))
                .setContentText(context.getString(R.string.notification_running_body, port, sentToday))
                .setContentIntent(pendingOpen)
                .setOngoing(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, context.getString(R.string.action_stop_gateway), pendingStop)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }
}
