package com.jmtechnology.smsgateway.ui.settings;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.android.material.textfield.TextInputEditText;
import com.jmtechnology.smsgateway.R;
import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SettingsActivity extends AppCompatActivity {

    private SettingsViewModel viewModel;
    private TextInputEditText etPort;
    private SwitchMaterial switchAutoStart;
    private SwitchMaterial switchBattery;
    private Button btnSaveSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        etPort = findViewById(R.id.etPort);
        switchAutoStart = findViewById(R.id.switchAutoStart);
        switchBattery = findViewById(R.id.switchBattery);
        btnSaveSettings = findViewById(R.id.btnSaveSettings);

        viewModel = new ViewModelProvider(this).get(SettingsViewModel.class);

        viewModel.getSettings().observe(this, settings -> {
            if (settings != null) {
                etPort.setText(String.valueOf(settings.getPort()));
                switchAutoStart.setChecked(settings.isAutoStartOnBoot());
                switchBattery.setChecked(settings.isIgnoreBatteryOptimization());
            }
        });

        viewModel.getSaveSuccess().observe(this, success -> {
            if (Boolean.TRUE.equals(success)) {
                Toast.makeText(this, "Settings saved. Restart gateway to apply port changes.", Toast.LENGTH_LONG).show();
                finish();
            }
        });

        viewModel.getErrorMessage().observe(this, err -> {
            if (err != null) {
                Toast.makeText(this, err, Toast.LENGTH_SHORT).show();
            }
        });

        btnSaveSettings.setOnClickListener(v -> {
            try {
                int port = Integer.parseInt(etPort.getText().toString().trim());
                boolean autoStart = switchAutoStart.isChecked();
                boolean battery = switchBattery.isChecked();
                viewModel.saveSettings(port, autoStart, battery);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid port number", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
