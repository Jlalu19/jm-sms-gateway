package com.jmtechnology.smsgateway.queue;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.hilt.work.HiltWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import com.jmtechnology.smsgateway.data.db.entities.SmsMessageEntity;
import com.jmtechnology.smsgateway.data.repository.SmsQueueRepository;
import com.jmtechnology.smsgateway.sms.SmsSender;
import dagger.assisted.Assisted;
import dagger.assisted.AssistedInject;
import java.util.List;

@HiltWorker
public class SmsSendWorker extends Worker {

    private final SmsQueueRepository queueRepository;
    private final SmsSender smsSender;

    @AssistedInject
    public SmsSendWorker(
            @Assisted @NonNull Context context,
            @Assisted @NonNull WorkerParameters workerParams,
            SmsQueueRepository queueRepository,
            SmsSender smsSender) {
        super(context, workerParams);
        this.queueRepository = queueRepository;
        this.smsSender = smsSender;
    }

    @NonNull
    @Override
    public Result doWork() {
        List<SmsMessageEntity> pending = queueRepository.getPendingMessages();
        for (SmsMessageEntity message : pending) {
            smsSender.sendSms(message);
        }
        return Result.success();
    }
}
