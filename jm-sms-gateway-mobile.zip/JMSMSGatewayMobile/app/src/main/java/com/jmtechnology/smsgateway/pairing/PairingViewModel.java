package com.jmtechnology.smsgateway.pairing;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.jmtechnology.smsgateway.core.BaseViewModel;
import dagger.hilt.android.lifecycle.HiltViewModel;
import javax.inject.Inject;

@HiltViewModel
public class PairingViewModel extends BaseViewModel {
    private final PairingRepository pairingRepository;
    private final MutableLiveData<String> pairSuccessMessage = new MutableLiveData<>();

    @Inject
    public PairingViewModel(PairingRepository pairingRepository) {
        this.pairingRepository = pairingRepository;
    }

    public LiveData<String> getPairSuccessMessage() {
        return pairSuccessMessage;
    }

    public void processQrContent(String qrContent) {
        setLoading(true);
        pairingRepository.pairFromQr(qrContent, new PairingRepository.PairingCallback() {
            @Override
            public void onSuccess(String computerName) {
                setLoading(false);
                pairSuccessMessage.setValue(computerName);
            }

            @Override
            public void onError(String error) {
                setLoading(false);
                setError(error);
            }
        });
    }
}
