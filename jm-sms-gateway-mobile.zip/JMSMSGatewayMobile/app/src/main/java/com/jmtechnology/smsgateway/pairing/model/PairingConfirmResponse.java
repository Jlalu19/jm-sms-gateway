package com.jmtechnology.smsgateway.pairing.model;

import com.google.gson.annotations.SerializedName;

public class PairingConfirmResponse {
    @SerializedName("success")
    public boolean success;

    @SerializedName("authToken")
    public String authToken;

    @SerializedName("message")
    public String message;
}
