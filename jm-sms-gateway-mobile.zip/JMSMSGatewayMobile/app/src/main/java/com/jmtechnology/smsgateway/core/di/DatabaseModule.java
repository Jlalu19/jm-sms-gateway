package com.jmtechnology.smsgateway.core.di;

import android.content.Context;
import com.jmtechnology.smsgateway.data.db.AppDatabase;
import com.jmtechnology.smsgateway.data.db.dao.GatewaySettingsDao;
import com.jmtechnology.smsgateway.data.db.dao.PairedDesktopDao;
import com.jmtechnology.smsgateway.data.db.dao.SmsLogDao;
import com.jmtechnology.smsgateway.data.db.dao.SmsMessageDao;
import dagger.Module;
import dagger.Provides;
import dagger.hilt.InstallIn;
import dagger.hilt.android.qualifiers.ApplicationContext;
import dagger.hilt.components.SingletonComponent;
import javax.inject.Singleton;

@Module
@InstallIn(SingletonComponent.class)
public class DatabaseModule {

    @Provides
    @Singleton
    public AppDatabase provideAppDatabase(@ApplicationContext Context context) {
        return AppDatabase.getInstance(context);
    }

    @Provides
    public SmsMessageDao provideSmsMessageDao(AppDatabase database) {
        return database.smsMessageDao();
    }

    @Provides
    public SmsLogDao provideSmsLogDao(AppDatabase database) {
        return database.smsLogDao();
    }

    @Provides
    public PairedDesktopDao providePairedDesktopDao(AppDatabase database) {
        return database.pairedDesktopDao();
    }

    @Provides
    public GatewaySettingsDao provideGatewaySettingsDao(AppDatabase database) {
        return database.gatewaySettingsDao();
    }
}
