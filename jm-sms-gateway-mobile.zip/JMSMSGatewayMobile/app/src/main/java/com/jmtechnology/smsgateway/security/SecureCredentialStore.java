package com.jmtechnology.smsgateway.security;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;
import com.jmtechnology.smsgateway.core.Constants;
import dagger.hilt.android.qualifiers.ApplicationContext;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class SecureCredentialStore {
    private SharedPreferences prefs;

    @Inject
    public SecureCredentialStore(@ApplicationContext Context context) {
        try {
            MasterKey masterKey = new MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();

            prefs = EncryptedSharedPreferences.create(
                    context,
                    Constants.PREF_FILE_SECURE,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (Exception e) {
            // Fallback for emulator / non-keystore environments
            prefs = context.getSharedPreferences(Constants.PREF_FILE_SECURE, Context.MODE_PRIVATE);
        }
    }

    public void savePairedDesktop(String desktopId, String secret, String host) {
        prefs.edit()
                .putString(Constants.PREF_PAIRED_DESKTOP_ID, desktopId)
                .putString(Constants.PREF_PAIRED_SECRET, secret)
                .putString(Constants.PREF_PAIRED_HOST, host)
                .apply();
    }

    public String getPairedDesktopId() {
        return prefs.getString(Constants.PREF_PAIRED_DESKTOP_ID, null);
    }

    public String getPairedSecret() {
        return prefs.getString(Constants.PREF_PAIRED_SECRET, null);
    }

    public String getPairedHost() {
        return prefs.getString(Constants.PREF_PAIRED_HOST, null);
    }

    public void clearPairedDesktop() {
        prefs.edit()
                .remove(Constants.PREF_PAIRED_DESKTOP_ID)
                .remove(Constants.PREF_PAIRED_SECRET)
                .remove(Constants.PREF_PAIRED_HOST)
                .apply();
    }

    public void saveAuthToken(String token) {
        prefs.edit().putString(Constants.PREF_AUTH_TOKEN, token).apply();
    }

    public String getAuthToken() {
        return prefs.getString(Constants.PREF_AUTH_TOKEN, null);
    }
}
