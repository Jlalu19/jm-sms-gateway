package com.jmtechnology.smsgateway.pairing.model;

import com.google.gson.annotations.SerializedName;

public class PairingQrPayload {
    @SerializedName("desktopId")
    public String desktopId;

    @SerializedName("licenseId")
    public String licenseId;

    @SerializedName("computerName")
    public String computerName;

    @SerializedName("pairingSecret")
    public String pairingSecret;

    @SerializedName("desktopHost")
    public String desktopHost;

    @SerializedName("desktopPort")
    public int desktopPort;

    @SerializedName("issuedAt")
    public long issuedAt;
}
