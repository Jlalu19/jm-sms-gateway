package com.jmtechnology.smsgateway.sms;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.telephony.SmsManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import com.jmtechnology.smsgateway.core.Constants;
import com.jmtechnology.smsgateway.data.db.entities.SmsMessageEntity;
import com.jmtechnology.smsgateway.data.repository.LogRepository;
import com.jmtechnology.smsgateway.permissions.PermissionManager;
import dagger.hilt.android.qualifiers.ApplicationContext;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class SmsSender {
    private final Context context;
    private final LogRepository logRepository;

    @Inject
    public SmsSender(@ApplicationContext Context context, LogRepository logRepository) {
        this.context = context;
        this.logRepository = logRepository;
    }

    public boolean sendSms(SmsMessageEntity message) {
        if (!PermissionManager.hasSmsPermission(context)) {
            logRepository.logError("SMS", "Cannot send SMS: SEND_SMS permission not granted");
            return false;
        }

        try {
            SmsManager smsManager = getSmsManagerForSlot(message.getSimSlot());
            String destination = message.getRecipient();
            String text = message.getMessageBody();

            ArrayList<String> parts = smsManager.divideMessage(text);
            int totalParts = parts.size();

            ArrayList<PendingIntent> sentIntents = new ArrayList<>();
            ArrayList<PendingIntent> deliveryIntents = new ArrayList<>();

            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }

            for (int i = 0; i < totalParts; i++) {
                Intent sentIntent = new Intent(context, SmsSentReceiver.class);
                sentIntent.setAction(Constants.ACTION_SMS_SENT);
                sentIntent.putExtra(Constants.EXTRA_MESSAGE_ID, message.getId());
                sentIntent.putExtra(Constants.EXTRA_PART_INDEX, i);
                sentIntent.putExtra(Constants.EXTRA_TOTAL_PARTS, totalParts);
                sentIntents.add(PendingIntent.getBroadcast(context, (int) (message.getId() * 100 + i), sentIntent, flags));

                Intent deliveryIntent = new Intent(context, SmsDeliveredReceiver.class);
                deliveryIntent.setAction(Constants.ACTION_SMS_DELIVERED);
                deliveryIntent.putExtra(Constants.EXTRA_MESSAGE_ID, message.getId());
                deliveryIntents.add(PendingIntent.getBroadcast(context, (int) (message.getId() * 100 + i + 50), deliveryIntent, flags));
            }

            if (totalParts > 1) {
                smsManager.sendMultipartTextMessage(destination, null, parts, sentIntents, deliveryIntents);
            } else {
                smsManager.sendTextMessage(destination, null, text, sentIntents.get(0), deliveryIntents.get(0));
            }

            logRepository.logSms(destination, "Dispatched " + totalParts + " part(s) via SIM slot " + message.getSimSlot(), "SENDING");
            return true;
        } catch (Exception e) {
            logRepository.logError("SMS", "Exception in sendSms: " + e.getMessage());
            return false;
        }
    }

    private SmsManager getSmsManagerForSlot(int simSlot) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            try {
                SubscriptionManager sm = (SubscriptionManager) context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
                if (sm != null && PermissionManager.hasPhoneStatePermission(context)) {
                    List<SubscriptionInfo> subList = sm.getActiveSubscriptionInfoList();
                    if (subList != null) {
                        for (SubscriptionInfo info : subList) {
                            if (info.getSimSlotIndex() == simSlot) {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                    return context.getSystemService(SmsManager.class).createForSubscriptionId(info.getSubscriptionId());
                                } else {
                                    return SmsManager.getSmsManagerForSubscriptionId(info.getSubscriptionId());
                                }
                            }
                        }
                    }
                }
            } catch (Exception ignored) {
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return context.getSystemService(SmsManager.class);
        } else {
            return SmsManager.getDefault();
        }
    }
}
