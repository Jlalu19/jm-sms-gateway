package com.jmtechnology.smsgateway.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import com.jmtechnology.smsgateway.data.db.entities.SmsLogEntity;
import java.util.List;

@Dao
public interface SmsLogDao {
    @Insert
    long insert(SmsLogEntity log);

    @Query("SELECT * FROM sms_logs ORDER BY timestamp DESC LIMIT :limit")
    LiveData<List<SmsLogEntity>> observeRecentLogs(int limit);

    @Query("SELECT * FROM sms_logs ORDER BY timestamp DESC LIMIT :limit")
    List<SmsLogEntity> getRecentLogsSync(int limit);

    @Query("SELECT * FROM sms_logs WHERE recipient LIKE '%' || :query || '%' OR message LIKE '%' || :query || '%' ORDER BY timestamp DESC LIMIT :limit")
    List<SmsLogEntity> searchLogs(String query, int limit);

    @Query("DELETE FROM sms_logs")
    void clearAllLogs();
}
