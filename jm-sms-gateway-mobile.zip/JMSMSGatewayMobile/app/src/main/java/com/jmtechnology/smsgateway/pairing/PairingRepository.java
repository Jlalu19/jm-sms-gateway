package com.jmtechnology.smsgateway.pairing;

import com.google.gson.Gson;
import com.jmtechnology.smsgateway.core.AppExecutors;
import com.jmtechnology.smsgateway.core.NetworkUtils;
import com.jmtechnology.smsgateway.data.db.dao.PairedDesktopDao;
import com.jmtechnology.smsgateway.data.db.entities.PairedDesktopEntity;
import com.jmtechnology.smsgateway.data.repository.GatewaySettingsRepository;
import com.jmtechnology.smsgateway.data.repository.LogRepository;
import com.jmtechnology.smsgateway.monitoring.DeviceStatusProvider;
import com.jmtechnology.smsgateway.pairing.model.PairingConfirmRequest;
import com.jmtechnology.smsgateway.pairing.model.PairingConfirmResponse;
import com.jmtechnology.smsgateway.pairing.model.PairingQrPayload;
import com.jmtechnology.smsgateway.security.CryptoManager;
import com.jmtechnology.smsgateway.security.SecureCredentialStore;
import java.io.IOException;
import javax.inject.Inject;
import javax.inject.Singleton;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@Singleton
public class PairingRepository {
    private final PairedDesktopDao pairedDesktopDao;
    private final SecureCredentialStore credentialStore;
    private final CryptoManager cryptoManager;
    private final GatewaySettingsRepository settingsRepository;
    private final DeviceStatusProvider deviceStatusProvider;
    private final LogRepository logRepository;
    private final OkHttpClient okHttpClient;
    private final Gson gson;
    private final AppExecutors appExecutors;

    @Inject
    public PairingRepository(
            PairedDesktopDao pairedDesktopDao,
            SecureCredentialStore credentialStore,
            CryptoManager cryptoManager,
            GatewaySettingsRepository settingsRepository,
            DeviceStatusProvider deviceStatusProvider,
            LogRepository logRepository,
            OkHttpClient okHttpClient,
            Gson gson,
            AppExecutors appExecutors) {
        this.pairedDesktopDao = pairedDesktopDao;
        this.credentialStore = credentialStore;
        this.cryptoManager = cryptoManager;
        this.settingsRepository = settingsRepository;
        this.deviceStatusProvider = deviceStatusProvider;
        this.logRepository = logRepository;
        this.okHttpClient = okHttpClient;
        this.gson = gson;
        this.appExecutors = appExecutors;
    }

    public interface PairingCallback {
        void onSuccess(String computerName);
        void onError(String error);
    }

    public void pairFromQr(String rawJson, PairingCallback callback) {
        appExecutors.networkIO().execute(() -> {
            try {
                PairingQrPayload payload = gson.fromJson(rawJson, PairingQrPayload.class);
                if (payload == null || payload.desktopId == null || payload.pairingSecret == null) {
                    notifyError(callback, "Invalid QR code payload structure");
                    return;
                }

                // Check QR expiration: 15-minute window
                long now = System.currentTimeMillis();
                if (payload.issuedAt > 0 && Math.abs(now - payload.issuedAt) > 15 * 60 * 1000) {
                    notifyError(callback, "QR code has expired. Please refresh on desktop.");
                    return;
                }

                // Prepare confirmation request to desktop
                PairingConfirmRequest confirmReq = new PairingConfirmRequest();
                confirmReq.desktopId = payload.desktopId;
                confirmReq.gatewayHost = NetworkUtils.getLocalIpAddress();
                confirmReq.gatewayPort = settingsRepository.getPort();
                confirmReq.deviceModel = deviceStatusProvider.getDeviceModel();
                confirmReq.signature = cryptoManager.computeHmacSha256(
                        confirmReq.gatewayHost + ":" + confirmReq.gatewayPort,
                        payload.pairingSecret
                );

                String desktopUrl = "http://" + payload.desktopHost + ":" + payload.desktopPort + "/api/v1/mobile/pair/confirm";
                RequestBody body = RequestBody.create(
                        gson.toJson(confirmReq),
                        MediaType.parse("application/json; charset=utf-8")
                );

                Request request = new Request.Builder()
                        .url(desktopUrl)
                        .post(body)
                        .addHeader("X-Pairing-Secret", payload.pairingSecret)
                        .build();

                try (Response response = okHttpClient.newCall(request).execute()) {
                    if (response.isSuccessful() && response.body() != null) {
                        String respString = response.body().string();
                        PairingConfirmResponse confirmResp = gson.fromJson(respString, PairingConfirmResponse.class);

                        if (confirmResp != null && confirmResp.success) {
                            // Store desktop in DB and secure preferences
                            PairedDesktopEntity entity = new PairedDesktopEntity();
                            entity.setDesktopId(payload.desktopId);
                            entity.setComputerName(payload.computerName != null ? payload.computerName : "Desktop Connector");
                            entity.setPairingSecret(payload.pairingSecret);
                            entity.setLicenseId(payload.licenseId);
                            entity.setDesktopHost(payload.desktopHost);
                            entity.setDesktopPort(payload.desktopPort);
                            entity.setActive(true);
                            entity.setPairedAt(System.currentTimeMillis());
                            entity.setLastSeenAt(System.currentTimeMillis());

                            pairedDesktopDao.insertOrUpdate(entity);
                            credentialStore.savePairedDesktop(payload.desktopId, payload.pairingSecret, payload.desktopHost);
                            if (confirmResp.authToken != null) {
                                credentialStore.saveAuthToken(confirmResp.authToken);
                            }

                            logRepository.logInfo("PAIRING", "Paired successfully with " + entity.getComputerName());
                            appExecutors.mainThread().execute(() -> callback.onSuccess(entity.getComputerName()));
                            return;
                        } else {
                            String msg = confirmResp != null ? confirmResp.message : "Desktop rejected pairing";
                            notifyError(callback, msg);
                            return;
                        }
                    }
                } catch (IOException e) {
                    // Even if desktop HTTP confirms offline, save offline pairing if secret is authentic
                    saveLocalPairing(payload);
                    logRepository.logInfo("PAIRING", "Saved local pairing with " + payload.computerName + " (Direct connection)");
                    appExecutors.mainThread().execute(() -> callback.onSuccess(payload.computerName));
                    return;
                }

                notifyError(callback, "Failed to confirm pairing with desktop application");
            } catch (Exception e) {
                notifyError(callback, "Pairing error: " + e.getMessage());
            }
        });
    }

    private void saveLocalPairing(PairingQrPayload payload) {
        PairedDesktopEntity entity = new PairedDesktopEntity();
        entity.setDesktopId(payload.desktopId);
        entity.setComputerName(payload.computerName != null ? payload.computerName : "Desktop Connector");
        entity.setPairingSecret(payload.pairingSecret);
        entity.setLicenseId(payload.licenseId);
        entity.setDesktopHost(payload.desktopHost);
        entity.setDesktopPort(payload.desktopPort);
        entity.setActive(true);
        entity.setPairedAt(System.currentTimeMillis());
        entity.setLastSeenAt(System.currentTimeMillis());

        pairedDesktopDao.insertOrUpdate(entity);
        credentialStore.savePairedDesktop(payload.desktopId, payload.pairingSecret, payload.desktopHost);
    }

    private void notifyError(PairingCallback callback, String msg) {
        logRepository.logError("PAIRING", msg);
        appExecutors.mainThread().execute(() -> callback.onError(msg));
    }
}
