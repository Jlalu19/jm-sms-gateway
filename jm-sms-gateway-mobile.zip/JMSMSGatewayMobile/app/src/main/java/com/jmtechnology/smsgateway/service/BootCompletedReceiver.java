package com.jmtechnology.smsgateway.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.content.ContextCompat;
import com.jmtechnology.smsgateway.data.db.AppDatabase;
import com.jmtechnology.smsgateway.data.db.entities.GatewaySettingsEntity;
import java.util.concurrent.Executors;

public class BootCompletedReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) ||
                "android.intent.action.QUICKBOOT_POWERON".equals(intent.getAction())) {

            Executors.newSingleThreadExecutor().execute(() -> {
                AppDatabase db = AppDatabase.getInstance(context);
                GatewaySettingsEntity settings = db.gatewaySettingsDao().getSettings();
                if (settings != null && settings.isAutoStartOnBoot()) {
                    Intent serviceIntent = new Intent(context, GatewayForegroundService.class);
                    ContextCompat.startForegroundService(context, serviceIntent);
                }
            });
        }
    }
}
