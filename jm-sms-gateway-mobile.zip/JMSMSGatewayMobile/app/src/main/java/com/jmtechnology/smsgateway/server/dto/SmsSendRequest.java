package com.jmtechnology.smsgateway.server.dto;

import com.google.gson.annotations.SerializedName;

public class SmsSendRequest {
    @SerializedName("clientMessageId")
    public String clientMessageId;

    @SerializedName("recipient")
    public String recipient;

    @SerializedName("message")
    public String message;

    @SerializedName("simSlot")
    public int simSlot = 0;

    @SerializedName("priority")
    public int priority = 1;
}
