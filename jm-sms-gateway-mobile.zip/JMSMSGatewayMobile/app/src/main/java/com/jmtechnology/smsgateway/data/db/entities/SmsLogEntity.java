package com.jmtechnology.smsgateway.data.db.entities;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "sms_logs")
public class SmsLogEntity {
    @PrimaryKey(autoGenerate = true)
    private long id;

    @NonNull
    private String category = "SMS"; // SMS, SERVER, PAIRING, SYSTEM

    @NonNull
    private String level = "INFO"; // INFO, WARNING, ERROR, SECURITY

    @NonNull
    private String message = "";

    private String recipient;

    private String status;

    private long timestamp = System.currentTimeMillis();

    // Getters and Setters
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    @NonNull
    public String getCategory() { return category; }
    public void setCategory(@NonNull String category) { this.category = category; }

    @NonNull
    public String getLevel() { return level; }
    public void setLevel(@NonNull String level) { this.level = level; }

    @NonNull
    public String getMessage() { return message; }
    public void setMessage(@NonNull String message) { this.message = message; }

    public String getRecipient() { return recipient; }
    public void setRecipient(String recipient) { this.recipient = recipient; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
}
