package com.jmtechnology.smsgateway.ui.logs;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.MaterialToolbar;
import com.jmtechnology.smsgateway.R;
import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class LogsActivity extends AppCompatActivity {

    private LogsViewModel viewModel;
    private LogsAdapter adapter;
    private EditText etSearchQuery;
    private Button btnExportCsv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logs);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        RecyclerView recyclerView = findViewById(R.id.recyclerViewLogs);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new LogsAdapter();
        recyclerView.setAdapter(adapter);

        etSearchQuery = findViewById(R.id.etSearchQuery);
        btnExportCsv = findViewById(R.id.btnExportCsv);

        viewModel = new ViewModelProvider(this).get(LogsViewModel.class);

        viewModel.getRecentLogs().observe(this, logs -> {
            if (etSearchQuery.getText().toString().trim().isEmpty()) {
                adapter.setLogs(logs);
            }
        });

        viewModel.getSearchResults().observe(this, results -> {
            if (results != null) {
                adapter.setLogs(results);
            }
        });

        viewModel.getExportedCsvUri().observe(this, (Uri uri) -> {
            if (uri != null) {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/csv");
                shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(shareIntent, "Share SMS Logs CSV"));
            }
        });

        viewModel.getErrorMessage().observe(this, err -> {
            if (err != null) {
                Toast.makeText(this, err, Toast.LENGTH_LONG).show();
            }
        });

        etSearchQuery.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int count, int after) {
                viewModel.search(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        btnExportCsv.setOnClickListener(v -> viewModel.exportToCsv(this));
    }
}
