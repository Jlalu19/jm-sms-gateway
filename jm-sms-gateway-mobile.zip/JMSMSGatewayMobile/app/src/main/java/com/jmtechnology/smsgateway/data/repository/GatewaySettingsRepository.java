package com.jmtechnology.smsgateway.data.repository;

import androidx.lifecycle.LiveData;
import com.jmtechnology.smsgateway.core.AppExecutors;
import com.jmtechnology.smsgateway.data.db.dao.GatewaySettingsDao;
import com.jmtechnology.smsgateway.data.db.entities.GatewaySettingsEntity;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class GatewaySettingsRepository {
    private final GatewaySettingsDao gatewaySettingsDao;
    private final AppExecutors appExecutors;

    @Inject
    public GatewaySettingsRepository(GatewaySettingsDao gatewaySettingsDao, AppExecutors appExecutors) {
        this.gatewaySettingsDao = gatewaySettingsDao;
        this.appExecutors = appExecutors;
    }

    public LiveData<GatewaySettingsEntity> getSettings() {
        return gatewaySettingsDao.observeSettings();
    }

    public GatewaySettingsEntity getSettingsSync() {
        GatewaySettingsEntity settings = gatewaySettingsDao.getSettings();
        if (settings == null) {
            settings = new GatewaySettingsEntity();
            settings.setId(1);
            settings.setPort(8080);
            settings.setMaxRetries(3);
            settings.setRetryDelaySeconds(5);
            settings.setAutoStartOnBoot(false);
            settings.setIgnoreBatteryOptimization(true);
            settings.setLanguage("en");
            settings.setTheme("default");
        }
        return settings;
    }

    public void updateSettings(GatewaySettingsEntity settings) {
        appExecutors.diskIO().execute(() -> {
            gatewaySettingsDao.insertOrUpdate(settings);
        });
    }

    public int getPort() {
        GatewaySettingsEntity s = getSettingsSync();
        return s != null ? s.getPort() : 8080;
    }

    public boolean isAutoStartEnabled() {
        GatewaySettingsEntity s = getSettingsSync();
        return s != null && s.isAutoStartOnBoot();
    }
}
