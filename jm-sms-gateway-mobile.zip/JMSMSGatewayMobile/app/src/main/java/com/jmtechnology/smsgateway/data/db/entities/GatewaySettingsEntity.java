package com.jmtechnology.smsgateway.data.db.entities;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "gateway_settings")
public class GatewaySettingsEntity {
    @PrimaryKey
    private int id = 1; // Single row settings

    private int port = 8080;

    private int maxRetries = 3;

    private int retryDelaySeconds = 5;

    private boolean autoStartOnBoot = false;

    private boolean ignoreBatteryOptimization = true;

    @NonNull
    private String language = "en";

    @NonNull
    private String theme = "default";

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getPort() { return port; }
    public void setPort(int port) { this.port = port; }

    public int getMaxRetries() { return maxRetries; }
    public void setMaxRetries(int maxRetries) { this.maxRetries = maxRetries; }

    public int getRetryDelaySeconds() { return retryDelaySeconds; }
    public void setRetryDelaySeconds(int retryDelaySeconds) { this.retryDelaySeconds = retryDelaySeconds; }

    public boolean isAutoStartOnBoot() { return autoStartOnBoot; }
    public void setAutoStartOnBoot(boolean autoStartOnBoot) { this.autoStartOnBoot = autoStartOnBoot; }

    public boolean isIgnoreBatteryOptimization() { return ignoreBatteryOptimization; }
    public void setIgnoreBatteryOptimization(boolean ignoreBatteryOptimization) { this.ignoreBatteryOptimization = ignoreBatteryOptimization; }

    @NonNull
    public String getLanguage() { return language; }
    public void setLanguage(@NonNull String language) { this.language = language; }

    @NonNull
    public String getTheme() { return theme; }
    public void setTheme(@NonNull String theme) { this.theme = theme; }
}
