package com.jmtechnology.smsgateway.data.db;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;
import com.jmtechnology.smsgateway.data.db.dao.GatewaySettingsDao;
import com.jmtechnology.smsgateway.data.db.dao.PairedDesktopDao;
import com.jmtechnology.smsgateway.data.db.dao.SmsLogDao;
import com.jmtechnology.smsgateway.data.db.dao.SmsMessageDao;
import com.jmtechnology.smsgateway.data.db.entities.GatewaySettingsEntity;
import com.jmtechnology.smsgateway.data.db.entities.PairedDesktopEntity;
import com.jmtechnology.smsgateway.data.db.entities.SmsLogEntity;
import com.jmtechnology.smsgateway.data.db.entities.SmsMessageEntity;
import java.util.concurrent.Executors;

@Database(entities = {
        SmsMessageEntity.class,
        SmsLogEntity.class,
        PairedDesktopEntity.class,
        GatewaySettingsEntity.class
}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    private static volatile AppDatabase INSTANCE;

    public abstract SmsMessageDao smsMessageDao();
    public abstract SmsLogDao smsLogDao();
    public abstract PairedDesktopDao pairedDesktopDao();
    public abstract GatewaySettingsDao gatewaySettingsDao();

    public static AppDatabase getInstance(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                            context.getApplicationContext(),
                            AppDatabase.class,
                            "jm_sms_gateway.db"
                    ).addCallback(new Callback() {
                        @Override
                        public void onCreate(@NonNull SupportSQLiteDatabase db) {
                            super.onCreate(db);
                            // Pre-populate default settings
                            Executors.newSingleThreadExecutor().execute(() -> {
                                GatewaySettingsEntity defaultSettings = new GatewaySettingsEntity();
                                defaultSettings.setId(1);
                                defaultSettings.setPort(8080);
                                defaultSettings.setMaxRetries(3);
                                defaultSettings.setRetryDelaySeconds(5);
                                defaultSettings.setAutoStartOnBoot(false);
                                defaultSettings.setIgnoreBatteryOptimization(true);
                                defaultSettings.setLanguage("en");
                                defaultSettings.setTheme("default");
                                getInstance(context).gatewaySettingsDao().insertOrUpdate(defaultSettings);
                            });
                        }
                    }).build();
                }
            }
        }
        return INSTANCE;
    }
}
