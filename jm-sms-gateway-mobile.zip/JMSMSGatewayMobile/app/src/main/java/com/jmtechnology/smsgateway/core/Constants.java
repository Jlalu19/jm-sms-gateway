package com.jmtechnology.smsgateway.core;

public final class Constants {
    private Constants() {}

    public static final String ACTION_START_GATEWAY = "com.jmtechnology.smsgateway.START_GATEWAY";
    public static final String ACTION_STOP_GATEWAY = "com.jmtechnology.smsgateway.STOP_GATEWAY";
    public static final String ACTION_GATEWAY_STATE_CHANGED = "com.jmtechnology.smsgateway.GATEWAY_STATE_CHANGED";
    public static final String EXTRA_GATEWAY_STATE = "gateway_state";

    public static final String ACTION_SMS_SENT = "com.jmtechnology.smsgateway.SMS_SENT";
    public static final String ACTION_SMS_DELIVERED = "com.jmtechnology.smsgateway.SMS_DELIVERED";
    public static final String EXTRA_MESSAGE_ID = "message_id";
    public static final String EXTRA_PART_INDEX = "part_index";
    public static final String EXTRA_TOTAL_PARTS = "total_parts";

    public static final int DEFAULT_HTTP_PORT = 8080;
    public static final int DEFAULT_MAX_RETRIES = 3;
    public static final int DEFAULT_RETRY_DELAY_SEC = 5;

    public static final String NOTIFICATION_CHANNEL_ID = "jm_sms_gateway_channel";
    public static final int NOTIFICATION_SERVICE_ID = 1001;

    public static final String PREF_FILE_SECURE = "jm_secure_prefs";
    public static final String PREF_PAIRED_DESKTOP_ID = "paired_desktop_id";
    public static final String PREF_PAIRED_SECRET = "paired_secret";
    public static final String PREF_PAIRED_HOST = "paired_host";
    public static final String PREF_AUTH_TOKEN = "auth_token";
}
