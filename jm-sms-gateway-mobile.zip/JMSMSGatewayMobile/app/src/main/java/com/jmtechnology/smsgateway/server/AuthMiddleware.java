package com.jmtechnology.smsgateway.server;

import com.jmtechnology.smsgateway.security.IpWhitelist;
import com.jmtechnology.smsgateway.security.NonceCache;
import com.jmtechnology.smsgateway.security.TokenManager;
import fi.iki.elonen.NanoHTTPD;
import java.util.Map;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class AuthMiddleware {
    private final IpWhitelist ipWhitelist;
    private final TokenManager tokenManager;
    private final NonceCache nonceCache;

    @Inject
    public AuthMiddleware(IpWhitelist ipWhitelist, TokenManager tokenManager, NonceCache nonceCache) {
        this.ipWhitelist = ipWhitelist;
        this.tokenManager = tokenManager;
        this.nonceCache = nonceCache;
    }

    public static class AuthResult {
        public final boolean isAuthorized;
        public final String errorMessage;
        public final int statusCode;

        public AuthResult(boolean isAuthorized, String errorMessage, int statusCode) {
            this.isAuthorized = isAuthorized;
            this.errorMessage = errorMessage;
            this.statusCode = statusCode;
        }

        public static AuthResult success() {
            return new AuthResult(true, null, 200);
        }

        public static AuthResult fail(String msg, int code) {
            return new AuthResult(false, msg, code);
        }
    }

    public AuthResult authenticate(NanoHTTPD.IHTTPSession session) {
        String remoteIp = session.getRemoteIpAddress();
        if (!ipWhitelist.isAllowed(remoteIp)) {
            return AuthResult.fail("Access forbidden: IP address not allowed on local gateway", 403);
        }

        // Status endpoint or pairing endpoint may have distinct auth rules
        String uri = session.getUri();
        if ("/api/v1/status".equals(uri) && session.getMethod() == NanoHTTPD.Method.GET) {
            return AuthResult.success(); // Open status check for discovery
        }

        Map<String, String> headers = session.getHeaders();
        String authHeader = headers.get("authorization");
        if (authHeader == null) {
            authHeader = headers.get("Authorization");
        }

        if (!tokenManager.validateToken(authHeader)) {
            return AuthResult.fail("Unauthorized: Missing or invalid authentication token", 401);
        }

        // Optional Nonce validation if headers provided
        String nonce = headers.get("x-nonce");
        String timestampStr = headers.get("x-timestamp");
        if (nonce != null && timestampStr != null) {
            try {
                long timestamp = Long.parseLong(timestampStr);
                if (!nonceCache.validateAndRecord(nonce, timestamp)) {
                    return AuthResult.fail("Unauthorized: Nonce replay detected or expired timestamp", 401);
                }
            } catch (NumberFormatException ignored) {
            }
        }

        return AuthResult.success();
    }
}
