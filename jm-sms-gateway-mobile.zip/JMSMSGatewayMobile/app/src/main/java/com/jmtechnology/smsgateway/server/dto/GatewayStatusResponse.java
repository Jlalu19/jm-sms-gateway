package com.jmtechnology.smsgateway.server.dto;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class GatewayStatusResponse {
    @SerializedName("success")
    public boolean success = true;

    @SerializedName("gatewayName")
    public String gatewayName = "JM SMS Gateway Mobile";

    @SerializedName("version")
    public String version;

    @SerializedName("status")
    public String status;

    @SerializedName("ipAddress")
    public String ipAddress;

    @SerializedName("port")
    public int port;

    @SerializedName("pairedDesktop")
    public String pairedDesktop;

    @SerializedName("simCards")
    public List<SimInfoResponse> simCards;

    @SerializedName("sentToday")
    public int sentToday;

    @SerializedName("failedToday")
    public int failedToday;

    @SerializedName("pendingQueue")
    public int pendingQueue;

    @SerializedName("battery")
    public String battery;

    public static class SimInfoResponse {
        @SerializedName("slot")
        public int slot;
        @SerializedName("operator")
        public String operator;
        @SerializedName("ready")
        public boolean ready;

        public SimInfoResponse(int slot, String operator, boolean ready) {
            this.slot = slot;
            this.operator = operator;
            this.ready = ready;
        }
    }
}
