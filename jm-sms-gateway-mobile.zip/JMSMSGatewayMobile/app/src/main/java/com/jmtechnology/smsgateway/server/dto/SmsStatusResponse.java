package com.jmtechnology.smsgateway.server.dto;

import com.google.gson.annotations.SerializedName;

public class SmsStatusResponse {
    @SerializedName("success")
    public boolean success;

    @SerializedName("clientMessageId")
    public String clientMessageId;

    @SerializedName("status")
    public String status; // PENDING, SENDING, SENT, DELIVERED, FAILED

    @SerializedName("failureReason")
    public String failureReason;

    @SerializedName("timestamp")
    public long timestamp = System.currentTimeMillis();

    public SmsStatusResponse(boolean success, String clientMessageId, String status, String failureReason) {
        this.success = success;
        this.clientMessageId = clientMessageId;
        this.status = status;
        this.failureReason = failureReason;
    }
}
