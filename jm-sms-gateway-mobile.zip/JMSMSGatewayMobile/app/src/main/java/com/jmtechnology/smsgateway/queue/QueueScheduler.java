package com.jmtechnology.smsgateway.queue;

import android.content.Context;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import dagger.hilt.android.qualifiers.ApplicationContext;
import java.util.concurrent.TimeUnit;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class QueueScheduler {
    private static final String UNIQUE_PERIODIC_WORK = "jm_sms_periodic_queue";
    private static final String UNIQUE_IMMEDIATE_WORK = "jm_sms_immediate_send";
    private final Context context;

    @Inject
    public QueueScheduler(@ApplicationContext Context context) {
        this.context = context;
    }

    public void schedulePeriodicQueueWorker() {
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(
                SmsSendWorker.class,
                15,
                TimeUnit.MINUTES
        ).build();

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_PERIODIC_WORK,
                ExistingPeriodicWorkPolicy.KEEP,
                request
        );
    }

    public void triggerImmediateSync() {
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(SmsSendWorker.class).build();
        WorkManager.getInstance(context).enqueueUniqueWork(
                UNIQUE_IMMEDIATE_WORK,
                ExistingWorkPolicy.REPLACE,
                request
        );
    }
}
