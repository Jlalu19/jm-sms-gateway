package com.jmtechnology.smsgateway.monitoring;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import androidx.core.content.ContextCompat;
import com.jmtechnology.smsgateway.BuildConfig;
import com.jmtechnology.smsgateway.core.NetworkUtils;
import com.jmtechnology.smsgateway.permissions.PermissionManager;
import dagger.hilt.android.qualifiers.ApplicationContext;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class DeviceStatusProvider {
    private final Context context;

    @Inject
    public DeviceStatusProvider(@ApplicationContext Context context) {
        this.context = context;
    }

    public static class SimInfo {
        public int slotIndex;
        public String displayName;
        public String carrierName;
        public boolean isReady;
    }

    public List<SimInfo> getSimCards() {
        List<SimInfo> sims = new ArrayList<>();
        if (!PermissionManager.hasPhoneStatePermission(context)) {
            SimInfo fallback = new SimInfo();
            fallback.slotIndex = 0;
            fallback.displayName = "SIM 1";
            fallback.carrierName = "Ethio telecom";
            fallback.isReady = true;
            sims.add(fallback);
            return sims;
        }

        try {
            SubscriptionManager sm = (SubscriptionManager) context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
            if (sm != null) {
                List<SubscriptionInfo> activeList = sm.getActiveSubscriptionInfoList();
                if (activeList != null && !activeList.isEmpty()) {
                    for (SubscriptionInfo info : activeList) {
                        SimInfo sim = new SimInfo();
                        sim.slotIndex = info.getSimSlotIndex();
                        sim.displayName = info.getDisplayName() != null ? info.getDisplayName().toString() : "SIM " + (info.getSimSlotIndex() + 1);
                        sim.carrierName = info.getCarrierName() != null ? info.getCarrierName().toString() : "Cellular";
                        sim.isReady = true;
                        sims.add(sim);
                    }
                }
            }
        } catch (SecurityException ignored) {
        }

        if (sims.isEmpty()) {
            TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            SimInfo defaultSim = new SimInfo();
            defaultSim.slotIndex = 0;
            defaultSim.displayName = "SIM 1";
            defaultSim.carrierName = (tm != null && tm.getNetworkOperatorName() != null && !tm.getNetworkOperatorName().isEmpty())
                    ? tm.getNetworkOperatorName() : "Ethio telecom";
            defaultSim.isReady = (tm != null && tm.getSimState() == TelephonyManager.SIM_STATE_READY);
            sims.add(defaultSim);
        }

        return sims;
    }

    public String getPrimaryOperatorName() {
        List<SimInfo> sims = getSimCards();
        if (!sims.isEmpty()) {
            return sims.get(0).carrierName;
        }
        return "Unknown";
    }

    public String getBatteryStatus() {
        try {
            IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent batteryStatus = context.registerReceiver(null, ifilter);
            if (batteryStatus != null) {
                int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                boolean isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                        status == BatteryManager.BATTERY_STATUS_FULL;

                int batteryPct = (int) ((level / (float) scale) * 100);
                return batteryPct + "%" + (isCharging ? " (Charging)" : "");
            }
        } catch (Exception ignored) {
        }
        return "Normal";
    }

    public String getIpAddress() {
        return NetworkUtils.getLocalIpAddress();
    }

    public String getAppVersion() {
        return BuildConfig.VERSION_NAME;
    }

    public String getDeviceModel() {
        return Build.MANUFACTURER + " " + Build.MODEL;
    }
}
