package com.jmtechnology.smsgateway.ui.settings;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.jmtechnology.smsgateway.core.BaseViewModel;
import com.jmtechnology.smsgateway.data.db.entities.GatewaySettingsEntity;
import com.jmtechnology.smsgateway.data.repository.GatewaySettingsRepository;
import dagger.hilt.android.lifecycle.HiltViewModel;
import javax.inject.Inject;

@HiltViewModel
public class SettingsViewModel extends BaseViewModel {

    private final GatewaySettingsRepository settingsRepository;
    private final MutableLiveData<Boolean> saveSuccess = new MutableLiveData<>();

    @Inject
    public SettingsViewModel(GatewaySettingsRepository settingsRepository) {
        this.settingsRepository = settingsRepository;
    }

    public LiveData<GatewaySettingsEntity> getSettings() {
        return settingsRepository.getSettings();
    }

    public LiveData<Boolean> getSaveSuccess() {
        return saveSuccess;
    }

    public void saveSettings(int port, boolean autoStart, boolean batteryOptimization) {
        if (port < 1024 || port > 65535) {
            setError("Port must be between 1024 and 65535");
            return;
        }

        GatewaySettingsEntity settings = settingsRepository.getSettingsSync();
        settings.setPort(port);
        settings.setAutoStartOnBoot(autoStart);
        settings.setIgnoreBatteryOptimization(batteryOptimization);

        settingsRepository.updateSettings(settings);
        saveSuccess.setValue(true);
    }
}
