package com.jmtechnology.smsgateway.data.db.entities;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "sms_messages", indices = {@Index(value = {"clientMessageId"}, unique = true)})
public class SmsMessageEntity {
    @PrimaryKey(autoGenerate = true)
    private long id;

    @NonNull
    private String clientMessageId = "";

    @NonNull
    private String recipient = "";

    @NonNull
    private String messageBody = "";

    private int simSlot = 0;

    private int retryCount = 0;

    private int maxRetries = 3;

    @NonNull
    private String status = "PENDING"; // PENDING, SENDING, SENT, DELIVERED, FAILED

    private String failureReason;

    private long createdAt = System.currentTimeMillis();

    private long updatedAt = System.currentTimeMillis();

    // Getters and Setters
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    @NonNull
    public String getClientMessageId() { return clientMessageId; }
    public void setClientMessageId(@NonNull String clientMessageId) { this.clientMessageId = clientMessageId; }

    @NonNull
    public String getRecipient() { return recipient; }
    public void setRecipient(@NonNull String recipient) { this.recipient = recipient; }

    @NonNull
    public String getMessageBody() { return messageBody; }
    public void setMessageBody(@NonNull String messageBody) { this.messageBody = messageBody; }

    public int getSimSlot() { return simSlot; }
    public void setSimSlot(int simSlot) { this.simSlot = simSlot; }

    public int getRetryCount() { return retryCount; }
    public void setRetryCount(int retryCount) { this.retryCount = retryCount; }

    public int getMaxRetries() { return maxRetries; }
    public void setMaxRetries(int maxRetries) { this.maxRetries = maxRetries; }

    @NonNull
    public String getStatus() { return status; }
    public void setStatus(@NonNull String status) { this.status = status; }

    public String getFailureReason() { return failureReason; }
    public void setFailureReason(String failureReason) { this.failureReason = failureReason; }

    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }

    public long getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(long updatedAt) { this.updatedAt = updatedAt; }
}
