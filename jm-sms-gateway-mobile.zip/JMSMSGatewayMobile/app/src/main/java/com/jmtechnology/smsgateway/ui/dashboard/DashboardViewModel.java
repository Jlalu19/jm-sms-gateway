package com.jmtechnology.smsgateway.ui.dashboard;

import android.os.Handler;
import android.os.Looper;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.jmtechnology.smsgateway.core.BaseViewModel;
import com.jmtechnology.smsgateway.data.db.dao.PairedDesktopDao;
import com.jmtechnology.smsgateway.data.db.entities.PairedDesktopEntity;
import com.jmtechnology.smsgateway.data.repository.GatewaySettingsRepository;
import com.jmtechnology.smsgateway.data.repository.SmsQueueRepository;
import com.jmtechnology.smsgateway.monitoring.DeviceStatusProvider;
import com.jmtechnology.smsgateway.monitoring.GatewayConnectionState;
import dagger.hilt.android.lifecycle.HiltViewModel;
import java.util.List;
import javax.inject.Inject;

@HiltViewModel
public class DashboardViewModel extends BaseViewModel {

    private final GatewayConnectionState connectionState;
    private final SmsQueueRepository queueRepository;
    private final GatewaySettingsRepository settingsRepository;
    private final DeviceStatusProvider deviceStatusProvider;
    private final PairedDesktopDao pairedDesktopDao;

    private final MutableLiveData<Integer> sentTodayCount = new MutableLiveData<>(0);
    private final MutableLiveData<Integer> failedTodayCount = new MutableLiveData<>(0);
    private final MutableLiveData<Integer> pendingCount = new MutableLiveData<>(0);
    private final MutableLiveData<Integer> totalSentCount = new MutableLiveData<>(0);
    private final MutableLiveData<String> batteryStatus = new MutableLiveData<>("100%");
    private final MutableLiveData<String> operatorName = new MutableLiveData<>("Ethio telecom");
    private final MutableLiveData<List<DeviceStatusProvider.SimInfo>> simCards = new MutableLiveData<>();

    private final Handler pollHandler = new Handler(Looper.getMainLooper());
    private final Runnable pollRunnable = new Runnable() {
        @Override
        public void run() {
            refreshMetrics();
            pollHandler.postDelayed(this, 5000); // 5-second polling
        }
    };

    @Inject
    public DashboardViewModel(
            GatewayConnectionState connectionState,
            SmsQueueRepository queueRepository,
            GatewaySettingsRepository settingsRepository,
            DeviceStatusProvider deviceStatusProvider,
            PairedDesktopDao pairedDesktopDao) {
        this.connectionState = connectionState;
        this.queueRepository = queueRepository;
        this.settingsRepository = settingsRepository;
        this.deviceStatusProvider = deviceStatusProvider;
        this.pairedDesktopDao = pairedDesktopDao;

        startPolling();
    }

    public LiveData<GatewayConnectionState.State> getGatewayState() {
        return connectionState.getCurrentState();
    }

    public LiveData<String> getServerUrl() {
        return connectionState.getServerUrl();
    }

    public LiveData<Integer> getSentTodayCount() {
        return sentTodayCount;
    }

    public LiveData<Integer> getFailedTodayCount() {
        return failedTodayCount;
    }

    public LiveData<Integer> getPendingCount() {
        return pendingCount;
    }

    public LiveData<Integer> getTotalSentCount() {
        return totalSentCount;
    }

    public LiveData<String> getBatteryStatus() {
        return batteryStatus;
    }

    public LiveData<String> getOperatorName() {
        return operatorName;
    }

    public LiveData<List<DeviceStatusProvider.SimInfo>> getSimCards() {
        return simCards;
    }

    public LiveData<PairedDesktopEntity> getActiveDesktop() {
        return pairedDesktopDao.observeActiveDesktop();
    }

    public void startPolling() {
        pollHandler.removeCallbacks(pollRunnable);
        pollHandler.post(pollRunnable);
    }

    public void stopPolling() {
        pollHandler.removeCallbacks(pollRunnable);
    }

    public void refreshMetrics() {
        new Thread(() -> {
            sentTodayCount.postValue(queueRepository.getSentTodayCount());
            failedTodayCount.postValue(queueRepository.getFailedTodayCount());
            pendingCount.postValue(queueRepository.getPendingCount());
            totalSentCount.postValue(queueRepository.getTotalSentCount());
            batteryStatus.postValue(deviceStatusProvider.getBatteryStatus());
            operatorName.postValue(deviceStatusProvider.getPrimaryOperatorName());
            simCards.postValue(deviceStatusProvider.getSimCards());
        }).start();
    }

    @Override
    protected void onCleared() {
        stopPolling();
        super.onCleared();
    }
}
