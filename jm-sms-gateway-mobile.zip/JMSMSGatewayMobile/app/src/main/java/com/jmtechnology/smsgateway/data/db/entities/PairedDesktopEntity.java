package com.jmtechnology.smsgateway.data.db.entities;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "paired_desktops")
public class PairedDesktopEntity {
    @PrimaryKey
    @NonNull
    private String desktopId = "";

    @NonNull
    private String computerName = "";

    @NonNull
    private String pairingSecret = "";

    private String licenseId;

    private String desktopHost;

    private int desktopPort;

    private boolean isActive = true;

    private long pairedAt = System.currentTimeMillis();

    private long lastSeenAt = System.currentTimeMillis();

    // Getters and Setters
    @NonNull
    public String getDesktopId() { return desktopId; }
    public void setDesktopId(@NonNull String desktopId) { this.desktopId = desktopId; }

    @NonNull
    public String getComputerName() { return computerName; }
    public void setComputerName(@NonNull String computerName) { this.computerName = computerName; }

    @NonNull
    public String getPairingSecret() { return pairingSecret; }
    public void setPairingSecret(@NonNull String pairingSecret) { this.pairingSecret = pairingSecret; }

    public String getLicenseId() { return licenseId; }
    public void setLicenseId(String licenseId) { this.licenseId = licenseId; }

    public String getDesktopHost() { return desktopHost; }
    public void setDesktopHost(String desktopHost) { this.desktopHost = desktopHost; }

    public int getDesktopPort() { return desktopPort; }
    public void setDesktopPort(int desktopPort) { this.desktopPort = desktopPort; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    public long getPairedAt() { return pairedAt; }
    public void setPairedAt(long pairedAt) { this.pairedAt = pairedAt; }

    public long getLastSeenAt() { return lastSeenAt; }
    public void setLastSeenAt(long lastSeenAt) { this.lastSeenAt = lastSeenAt; }
}
