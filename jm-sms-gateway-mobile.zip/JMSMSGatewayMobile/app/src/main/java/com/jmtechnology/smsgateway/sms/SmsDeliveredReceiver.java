package com.jmtechnology.smsgateway.sms;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.jmtechnology.smsgateway.core.Constants;
import com.jmtechnology.smsgateway.data.db.AppDatabase;
import com.jmtechnology.smsgateway.data.db.entities.SmsLogEntity;
import com.jmtechnology.smsgateway.data.db.entities.SmsMessageEntity;
import java.util.concurrent.Executors;

public class SmsDeliveredReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Constants.ACTION_SMS_DELIVERED.equals(intent.getAction())) return;

        long messageId = intent.getLongExtra(Constants.EXTRA_MESSAGE_ID, -1);
        int resultCode = getResultCode();

        Executors.newSingleThreadExecutor().execute(() -> {
            AppDatabase db = AppDatabase.getInstance(context);
            SmsMessageEntity entity = db.smsMessageDao().getById(messageId);
            if (entity == null) return;

            if (resultCode == Activity.RESULT_OK) {
                db.smsMessageDao().updateStatus(messageId, "DELIVERED", System.currentTimeMillis(), null);
                SmsLogEntity log = new SmsLogEntity();
                log.setCategory("SMS");
                log.setLevel("INFO");
                log.setMessage("Delivery confirmed by carrier for " + entity.getRecipient());
                log.setRecipient(entity.getRecipient());
                log.setStatus("DELIVERED");
                log.setTimestamp(System.currentTimeMillis());
                db.smsLogDao().insert(log);
            }
        });
    }
}
