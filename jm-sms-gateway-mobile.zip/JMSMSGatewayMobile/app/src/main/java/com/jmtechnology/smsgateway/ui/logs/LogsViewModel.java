package com.jmtechnology.smsgateway.ui.logs;

import android.content.Context;
import android.net.Uri;
import androidx.core.content.FileProvider;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.jmtechnology.smsgateway.core.AppExecutors;
import com.jmtechnology.smsgateway.core.BaseViewModel;
import com.jmtechnology.smsgateway.data.db.entities.SmsLogEntity;
import com.jmtechnology.smsgateway.data.repository.LogRepository;
import dagger.hilt.android.lifecycle.HiltViewModel;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.inject.Inject;

@HiltViewModel
public class LogsViewModel extends BaseViewModel {

    private final LogRepository logRepository;
    private final AppExecutors appExecutors;
    private final MutableLiveData<List<SmsLogEntity>> searchResults = new MutableLiveData<>();
    private final MutableLiveData<Uri> exportedCsvUri = new MutableLiveData<>();

    @Inject
    public LogsViewModel(LogRepository logRepository, AppExecutors appExecutors) {
        this.logRepository = logRepository;
        this.appExecutors = appExecutors;
    }

    public LiveData<List<SmsLogEntity>> getRecentLogs() {
        return logRepository.getRecentLogs(100);
    }

    public LiveData<List<SmsLogEntity>> getSearchResults() {
        return searchResults;
    }

    public LiveData<Uri> getExportedCsvUri() {
        return exportedCsvUri;
    }

    public void search(String query) {
        if (query == null || query.trim().isEmpty()) {
            searchResults.setValue(null);
            return;
        }

        appExecutors.diskIO().execute(() -> {
            List<SmsLogEntity> results = logRepository.searchLogs(query.trim(), 100);
            searchResults.postValue(results);
        });
    }

    public void exportToCsv(Context context) {
        setLoading(true);
        appExecutors.diskIO().execute(() -> {
            try {
                List<SmsLogEntity> allLogs = logRepository.getRecentLogsSync(1000);
                File exportDir = new File(context.getCacheDir(), "logs");
                if (!exportDir.exists()) exportDir.mkdirs();

                String fileName = "sms_logs_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date()) + ".csv";
                File csvFile = new File(exportDir, fileName);

                try (FileWriter writer = new FileWriter(csvFile)) {
                    writer.append("ID,Timestamp,Category,Level,Recipient,Status,Message\n");
                    for (SmsLogEntity log : allLogs) {
                        writer.append(String.valueOf(log.getId())).append(",");
                        writer.append(String.valueOf(log.getTimestamp())).append(",");
                        writer.append(escapeCsv(log.getCategory())).append(",");
                        writer.append(escapeCsv(log.getLevel())).append(",");
                        writer.append(escapeCsv(log.getRecipient() != null ? log.getRecipient() : "")).append(",");
                        writer.append(escapeCsv(log.getStatus() != null ? log.getStatus() : "")).append(",");
                        writer.append(escapeCsv(log.getMessage())).append("\n");
                    }
                }

                Uri uri = FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", csvFile);
                setLoading(false);
                exportedCsvUri.postValue(uri);
            } catch (Exception e) {
                setLoading(false);
                setError("Export failed: " + e.getMessage());
            }
        });
    }

    private String escapeCsv(String val) {
        if (val == null) return "\"\"";
        return "\"" + val.replace("\"", "\"\"") + "\"";
    }
}
