package com.jmtechnology.smsgateway.sms;

import com.jmtechnology.smsgateway.security.CryptoManager;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class DuplicateGuard {
    private static final long DEBOUNCE_WINDOW_MS = 60 * 1000; // 60 seconds
    private final Map<String, Long> sentHashes = new ConcurrentHashMap<>();
    private final CryptoManager cryptoManager;

    @Inject
    public DuplicateGuard(CryptoManager cryptoManager) {
        this.cryptoManager = cryptoManager;
    }

    public synchronized boolean isDuplicate(String recipient, String message) {
        cleanOldEntries();
        String hash = cryptoManager.sha256(recipient + "::" + message);
        Long lastSent = sentHashes.get(hash);
        return lastSent != null && (System.currentTimeMillis() - lastSent < DEBOUNCE_WINDOW_MS);
    }

    public synchronized void recordSent(String recipient, String message) {
        cleanOldEntries();
        String hash = cryptoManager.sha256(recipient + "::" + message);
        sentHashes.put(hash, System.currentTimeMillis());
    }

    private void cleanOldEntries() {
        long now = System.currentTimeMillis();
        sentHashes.entrySet().removeIf(entry -> now - entry.getValue() > DEBOUNCE_WINDOW_MS);
    }
}
