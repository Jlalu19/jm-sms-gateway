package com.jmtechnology.smsgateway.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import com.jmtechnology.smsgateway.R;
import com.jmtechnology.smsgateway.core.Constants;
import com.jmtechnology.smsgateway.monitoring.DeviceStatusProvider;
import com.jmtechnology.smsgateway.monitoring.GatewayConnectionState;
import com.jmtechnology.smsgateway.pairing.PairingActivity;
import com.jmtechnology.smsgateway.permissions.PermissionManager;
import com.jmtechnology.smsgateway.service.GatewayForegroundService;
import com.jmtechnology.smsgateway.ui.dashboard.DashboardViewModel;
import com.jmtechnology.smsgateway.ui.logs.LogsActivity;
import com.jmtechnology.smsgateway.ui.settings.SettingsActivity;
import dagger.hilt.android.AndroidEntryPoint;
import java.util.List;

@AndroidEntryPoint
public class MainActivity extends AppCompatActivity {

    private DashboardViewModel viewModel;

    private View viewStatusIndicator;
    private TextView tvGatewayStatus;
    private TextView tvEndpointAddress;
    private TextView tvPairedDesktop;
    private Button btnToggleGateway;

    private TextView tvSentTodayCount;
    private TextView tvFailedCount;
    private TextView tvPendingCount;
    private TextView tvTotalCount;

    private TextView tvSimStatus;
    private TextView tvOperator;
    private TextView tvBattery;
    private TextView tvIpAddress;

    private GatewayConnectionState.State currentServiceState = GatewayConnectionState.State.STOPPED;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        viewModel = new ViewModelProvider(this).get(DashboardViewModel.class);
        observeState();

        btnToggleGateway.setOnClickListener(v -> toggleGatewayService());

        // Check runtime permissions
        if (!PermissionManager.hasAllCorePermissions(this)) {
            PermissionManager.requestCorePermissions(this);
        }
    }

    private void initViews() {
        viewStatusIndicator = findViewById(R.id.viewStatusIndicator);
        tvGatewayStatus = findViewById(R.id.tvGatewayStatus);
        tvEndpointAddress = findViewById(R.id.tvEndpointAddress);
        tvPairedDesktop = findViewById(R.id.tvPairedDesktop);
        btnToggleGateway = findViewById(R.id.btnToggleGateway);

        tvSentTodayCount = findViewById(R.id.tvSentTodayCount);
        tvFailedCount = findViewById(R.id.tvFailedCount);
        tvPendingCount = findViewById(R.id.tvPendingCount);
        tvTotalCount = findViewById(R.id.tvTotalCount);

        tvSimStatus = findViewById(R.id.tvSimStatus);
        tvOperator = findViewById(R.id.tvOperator);
        tvBattery = findViewById(R.id.tvBattery);
        tvIpAddress = findViewById(R.id.tvIpAddress);

        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    private void observeState() {
        // Fix for Issue: Observe actual service state rather than local boolean
        viewModel.getGatewayState().observe(this, state -> {
            currentServiceState = state;
            updateServiceUi(state);
        });

        viewModel.getServerUrl().observe(this, url -> {
            if (url != null && !url.isEmpty()) {
                tvEndpointAddress.setText(getString(R.string.status_listening_on, url));
            } else {
                tvEndpointAddress.setText(R.string.status_no_wifi);
            }
        });

        viewModel.getActiveDesktop().observe(this, desktop -> {
            if (desktop != null && desktop.isActive()) {
                tvPairedDesktop.setText(getString(R.string.paired_desktop_label, desktop.getComputerName()));
            } else {
                tvPairedDesktop.setText("No desktop paired — Tap Camera icon to pair");
            }
        });

        viewModel.getSentTodayCount().observe(this, count -> tvSentTodayCount.setText(String.valueOf(count)));
        viewModel.getFailedTodayCount().observe(this, count -> tvFailedCount.setText(String.valueOf(count)));
        viewModel.getPendingCount().observe(this, count -> tvPendingCount.setText(String.valueOf(count)));
        viewModel.getTotalSentCount().observe(this, count -> tvTotalCount.setText(String.valueOf(count)));

        viewModel.getBatteryStatus().observe(this, battery -> tvBattery.setText(battery));
        viewModel.getOperatorName().observe(this, op -> tvOperator.setText(op));

        viewModel.getSimCards().observe(this, (List<DeviceStatusProvider.SimInfo> sims) -> {
            if (sims != null && !sims.isEmpty()) {
                tvSimStatus.setText(sims.size() + " SIM(s) Ready");
            } else {
                tvSimStatus.setText("No SIM Detected");
            }
        });
    }

    private void updateServiceUi(GatewayConnectionState.State state) {
        switch (state) {
            case RUNNING:
                viewStatusIndicator.setBackgroundColor(ContextCompat.getColor(this, R.color.status_green));
                tvGatewayStatus.setText(R.string.status_running);
                tvGatewayStatus.setTextColor(ContextCompat.getColor(this, R.color.status_green));
                btnToggleGateway.setText(R.string.action_stop_gateway);
                btnToggleGateway.setEnabled(true);
                break;
            case STARTING:
                viewStatusIndicator.setBackgroundColor(ContextCompat.getColor(this, R.color.status_amber));
                tvGatewayStatus.setText(R.string.action_starting);
                btnToggleGateway.setEnabled(false);
                break;
            case STOPPING:
                viewStatusIndicator.setBackgroundColor(ContextCompat.getColor(this, R.color.status_amber));
                tvGatewayStatus.setText(R.string.action_stopping);
                btnToggleGateway.setEnabled(false);
                break;
            case STOPPED:
            case ERROR:
            default:
                viewStatusIndicator.setBackgroundColor(ContextCompat.getColor(this, R.color.status_red));
                tvGatewayStatus.setText(R.string.status_stopped);
                tvGatewayStatus.setTextColor(ContextCompat.getColor(this, R.color.status_red));
                btnToggleGateway.setText(R.string.action_start_gateway);
                btnToggleGateway.setEnabled(true);
                break;
        }
    }

    private void toggleGatewayService() {
        Intent serviceIntent = new Intent(this, GatewayForegroundService.class);
        if (currentServiceState == GatewayConnectionState.State.RUNNING) {
            serviceIntent.setAction(Constants.ACTION_STOP_GATEWAY);
            startService(serviceIntent);
        } else {
            serviceIntent.setAction(Constants.ACTION_START_GATEWAY);
            ContextCompat.startForegroundService(this, serviceIntent);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_dashboard, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_pairing) {
            startActivity(new Intent(this, PairingActivity.class));
            return true;
        } else if (id == R.id.action_logs) {
            startActivity(new Intent(this, LogsActivity.class));
            return true;
        } else if (id == R.id.action_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (viewModel != null) {
            viewModel.startPolling();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (viewModel != null) {
            viewModel.stopPolling();
        }
    }
}
