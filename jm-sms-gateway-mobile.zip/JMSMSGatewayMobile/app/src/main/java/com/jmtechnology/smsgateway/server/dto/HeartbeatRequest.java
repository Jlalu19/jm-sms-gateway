package com.jmtechnology.smsgateway.server.dto;

import com.google.gson.annotations.SerializedName;

public class HeartbeatRequest {
    @SerializedName("desktopId")
    public String desktopId;

    @SerializedName("nonce")
    public String nonce;

    @SerializedName("timestamp")
    public long timestamp;
}
