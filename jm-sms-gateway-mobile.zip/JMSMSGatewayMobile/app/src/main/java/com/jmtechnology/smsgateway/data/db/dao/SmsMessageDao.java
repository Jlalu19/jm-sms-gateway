package com.jmtechnology.smsgateway.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;
import com.jmtechnology.smsgateway.data.db.entities.SmsMessageEntity;
import java.util.List;

@Dao
public interface SmsMessageDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    long insert(SmsMessageEntity message);

    @Update
    void update(SmsMessageEntity message);

    @Query("SELECT * FROM sms_messages WHERE id = :id LIMIT 1")
    SmsMessageEntity getById(long id);

    @Query("SELECT * FROM sms_messages WHERE clientMessageId = :clientMessageId LIMIT 1")
    SmsMessageEntity getByClientMessageId(String clientMessageId);

    @Query("SELECT * FROM sms_messages WHERE status = 'PENDING' ORDER BY createdAt ASC")
    List<SmsMessageEntity> getPendingMessages();

    @Query("SELECT COUNT(*) FROM sms_messages WHERE status = 'SENT' AND createdAt >= :sinceTimestamp")
    int countSentSince(long sinceTimestamp);

    @Query("SELECT COUNT(*) FROM sms_messages WHERE status = 'FAILED' AND createdAt >= :sinceTimestamp")
    int countFailedSince(long sinceTimestamp);

    @Query("SELECT COUNT(*) FROM sms_messages WHERE status = 'PENDING'")
    int countPending();

    @Query("SELECT COUNT(*) FROM sms_messages WHERE status = 'SENT'")
    int countTotalSent();

    @Query("SELECT COUNT(*) FROM sms_messages WHERE status = 'SENT'")
    LiveData<Integer> observeTotalSent();

    @Query("SELECT COUNT(*) FROM sms_messages WHERE status = 'PENDING'")
    LiveData<Integer> observePending();

    @Query("UPDATE sms_messages SET status = :status, updatedAt = :updatedAt, failureReason = :reason WHERE id = :id")
    void updateStatus(long id, String status, long updatedAt, String reason);
}
