package com.jmtechnology.smsgateway.monitoring;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class GatewayConnectionState {
    public enum State {
        STOPPED,
        STARTING,
        RUNNING,
        STOPPING,
        ERROR
    }

    private final MutableLiveData<State> currentState = new MutableLiveData<>(State.STOPPED);
    private final MutableLiveData<String> serverUrl = new MutableLiveData<>("");
    private final MutableLiveData<Integer> activePort = new MutableLiveData<>(8080);
    private final MutableLiveData<String> errorMessage = new MutableLiveData<>("");

    @Inject
    public GatewayConnectionState() {
    }

    public LiveData<State> getCurrentState() {
        return currentState;
    }

    public State getStateSync() {
        return currentState.getValue() != null ? currentState.getValue() : State.STOPPED;
    }

    public boolean isRunning() {
        return getStateSync() == State.RUNNING;
    }

    public void setState(State state) {
        currentState.postValue(state);
    }

    public LiveData<String> getServerUrl() {
        return serverUrl;
    }

    public void setServerUrl(String url) {
        serverUrl.postValue(url);
    }

    public LiveData<Integer> getActivePort() {
        return activePort;
    }

    public void setActivePort(int port) {
        activePort.postValue(port);
    }

    public LiveData<String> getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String error) {
        errorMessage.postValue(error);
    }
}
