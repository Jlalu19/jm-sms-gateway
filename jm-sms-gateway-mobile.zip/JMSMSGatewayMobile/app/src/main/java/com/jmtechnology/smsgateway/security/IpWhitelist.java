package com.jmtechnology.smsgateway.security;

import java.net.InetAddress;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class IpWhitelist {

    @Inject
    public IpWhitelist() {}

    public boolean isAllowed(String remoteIp) {
        if (remoteIp == null) return false;
        try {
            // Localhost is always allowed
            if (remoteIp.equals("127.0.0.1") || remoteIp.equals("::1") || remoteIp.equals("localhost")) {
                return true;
            }

            InetAddress addr = InetAddress.getByName(remoteIp);
            // Allow private network addresses (RFC 1918)
            return addr.isSiteLocalAddress() || addr.isLoopbackAddress() || addr.isLinkLocalAddress();
        } catch (Exception e) {
            return false;
        }
    }
}
