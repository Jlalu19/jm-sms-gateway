package com.jmtechnology.smsgateway.server.dto;

import com.google.gson.annotations.SerializedName;

public class ErrorResponse {
    @SerializedName("success")
    public boolean success = false;

    @SerializedName("error")
    public String error;

    @SerializedName("errorCode")
    public int errorCode;

    @SerializedName("timestamp")
    public long timestamp = System.currentTimeMillis();

    public ErrorResponse(String error, int errorCode) {
        this.error = error;
        this.errorCode = errorCode;
    }
}
