# Proguard rules for JM SMS Gateway Mobile
-keepattributes *Annotation*
-keepclassmembers class * {
    @org.nanohttpd.protocols.http.NanoHTTPD$* <methods>;
}

# Keep DTO classes for GSON
-keep class com.jmtechnology.smsgateway.server.dto.** { *; }
-keep class com.jmtechnology.smsgateway.pairing.model.** { *; }
-keep class com.jmtechnology.smsgateway.data.db.entities.** { *; }

# Room
-keep class androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# Hilt
-keep class com.jmtechnology.smsgateway.Hilt_* { *; }
-keep class * extends dagger.hilt.android.internal.managers.ViewComponentManager$FragmentContextWrapper { *; }
