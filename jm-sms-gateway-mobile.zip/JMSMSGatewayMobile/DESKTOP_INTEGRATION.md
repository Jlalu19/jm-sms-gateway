# JM SMS Connector — Desktop Integration Protocol

## 1. Network Discovery & Status
- **Method**: `GET /api/v1/status`
- **Headers**: None required for discovery
- **Response**:
```json
{
  "success": true,
  "gatewayName": "JM SMS Gateway Mobile",
  "version": "1.0.0",
  "status": "RUNNING",
  "ipAddress": "192.168.1.50",
  "port": 8080,
  "pairedDesktop": "DESKTOP-JM-01",
  "simCards": [
    { "slot": 0, "operator": "Ethio telecom", "ready": true }
  ],
  "sentToday": 142,
  "failedToday": 2,
  "pendingQueue": 0,
  "battery": "94% (Charging)"
}
```

## 2. Dispatch SMS
- **Method**: `POST /api/v1/sms/send`
- **Headers**:
  - `Authorization: Bearer <pairingSecret_or_authToken>`
  - `X-Nonce: <unique_uuid>`
  - `X-Timestamp: <epoch_ms>`
  - `Content-Type: application/json`
- **Request Body**:
```json
{
  "clientMessageId": "desktop_order_99812",
  "recipient": "+251911223344",
  "message": "ውድ ደንበኛችን፣ የትዕዛዝ ቁጥርዎ 99812 ተጠናቅቋል። JM Technology",
  "simSlot": 0,
  "priority": 1
}
```
- **Response**:
```json
{
  "success": true,
  "clientMessageId": "desktop_order_99812",
  "status": "PENDING"
}
```

## 3. Query SMS Delivery
- **Method**: `GET /api/v1/sms/status?id=desktop_order_99812`
- **Headers**: `Authorization: Bearer <token>`
- **Response**:
```json
{
  "success": true,
  "clientMessageId": "desktop_order_99812",
  "status": "DELIVERED",
  "failureReason": null,
  "timestamp": 1727187600000
}
```

## 4. Heartbeat
- **Method**: `POST /api/v1/heartbeat`
- **Headers**: `Authorization: Bearer <token>`
- **Response**:
```json
{
  "success": true,
  "gatewayStatus": "ONLINE",
  "serverTime": 1727187605120,
  "pendingQueue": 0,
  "batteryLevel": "94%"
}
```
