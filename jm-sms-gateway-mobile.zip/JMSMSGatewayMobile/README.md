# JM SMS Gateway Mobile

Developed by **JM Technology**  
Application ID: `com.jmtechnology.smsgateway`  
Target SDK: 35 | Minimum SDK: 26  
Architecture: **MVVM + Repository + Room + Hilt + WorkManager + Foreground Service**

## Overview
JM SMS Gateway Mobile turns an Android smartphone equipped with one or multiple SIM cards into a high-performance local SMS gateway for **JM SMS Connector Desktop**.

## Key Architecture & Features
- **Local HTTP Gateway (NanoHTTPD)**: Binds to local IP and configurable port (default `8080`), accepting encrypted/token-authorized SMS dispatches from desktop connector.
- **Dual SIM & Telephony**: Multi-slot SIM detection and automated multi-part SMS concatenation (supporting GSM 7-bit and UCS-2 Amharic).
- **Service State Fix**: Employs `GatewayConnectionState` singleton LiveData bound to `GatewayForegroundService` life-cycle to eliminate activity recreation state drift.
- **Zero-Trust Security**: Subnet validation, Token authentication, Nonce replay prevention (5-min sliding window), and duplicate message guard (60s debounce).
- **QR Desktop Pairing**: CameraX + ZXing barcode analysis for fast, cryptographic pairing between desktop connector and gateway phone.
- **Bilingual Interface**: Full native localization in **English** and **Amharic (አማርኛ)**.
- **Room Database**: Persistent storage for incoming queue, logs, and paired desktops.
